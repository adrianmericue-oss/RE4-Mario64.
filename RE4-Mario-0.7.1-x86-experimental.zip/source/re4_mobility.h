#pragma once
#include "re4_camera_math.h"
#include <cstdint>
namespace MarioMobility {
// re4_tweaks SCF progression flags: puzzles, opened routes, chapter/boss/rescue changes.
// Mere ENTER/seen-cutscene flags do not qualify as progression.
inline bool StoryFlagsChanged(const uint32_t* before,const uint32_t* after){
 const unsigned ids[]={2,11,13,16,21,23,25,28,29,30,31,32,33,35,37,38,39,40,44,45,46,47,48,52,54,55,56,57,64,65,67,68,69,77,78,81,83,84,85,87,90,187,188,189,191,192,194};
 for(unsigned id:ids)if((before[id/32]^after[id/32])&(0x80000000u>>(id%32)))return true;
 return false;
}
template<class FloorQuery> bool FindDrop(Vec position,Vec direction,const std::vector<MarioCamera::Triangle>& world,FloorQuery floor,Vec& result){
 using namespace MarioCamera;direction.y=0;direction=Unit(direction);
 // A lower floor must exist beyond a low ledge. Solid tall walls remain blocking.
 for(float distance:{450.f,700.f,1000.f}){
  Vec candidate=Add(position,Mul(direction,distance));float below=floor(candidate);
  float drop=position.y-below;if(!std::isfinite(below)||drop<300||drop>6000)continue;
  if(RayWorld(Add(position,{0,1800,0}),Add(candidate,{0,1800,0}),world)<1)continue;
  if(RayWorld(Add(candidate,{0,100,0}),Add(candidate,{0,-200,0}),world)<1)continue;
  result=candidate;return true;
 }
 return false;
}
}
