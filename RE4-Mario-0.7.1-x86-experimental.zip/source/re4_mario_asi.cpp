// RE4 UHD + libsm64 exploration prototype. No retail code/assets embedded.
// SDK layout and pattern references: nipkownix/re4_tweaks (GPLv3).
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <d3d9.h>
#include <xinput.h>
#include <mmsystem.h>
#include <stdint.h>
#include <cstdio>
#include <cmath>
#include <vector>
#include <algorithm>
#include <cstring>
#include <string>
#include "libsm64.h"
#include "re4_camera_math.h"
#include "re4_mobility.h"

static HMODULE selfModule, realD3D;
static std::wstring modDir;
static FILE* logFile;
static uint8_t **globalPtr, **playerPtr;
static uint8_t *satMgr, *eatMgr, *emMgr;
static bool checked=false, compatible=false, initialized=false, active=false;
static bool doorHookReady=false,doorNativePending=false,doorWalkIntent=false;
static uint8_t doorRoutineBefore=0;
static float doorElapsed=0;
static ULONGLONG doorCooldown=0;
using ActionSetFn=void(__fastcall*)(void*,void*,int,int,void*,void*,int,int,int,void*);
using ActionButtonFn=bool(__fastcall*)(void*,void*,uint8_t*);
static ActionSetFn originalActionSet=nullptr;
static ActionButtonFn originalActionButton=nullptr;
static void __fastcall HookActionSet(void*,void*,int,int,void*,void*,int,int,int,void*);
static bool __fastcall HookActionButton(void*,void*,uint8_t*);
// Render callbacks and PadRead may execute on different RE4 threads. Keep
// Mario's lifetime and geometry stable throughout each render/physics operation.
static CRITICAL_SECTION* MarioStateLock(){static CRITICAL_SECTION* lock=[](){auto p=new CRITICAL_SECTION;InitializeCriticalSection(p);return p;}();return lock;}
struct MarioGuard{MarioGuard(){EnterCriticalSection(MarioStateLock());}~MarioGuard(){LeaveCriticalSection(MarioStateLock());}};
static uint8_t *ownedPlayer=nullptr, *ownedGlobal=nullptr;
static uint32_t oldDrawBits=0;
static bool oldPlayerStop=false;
static Vec origin{}, recovery{};
static int marioId=-1;
static uint16_t currentRoom=0xffff;
static std::vector<uint8_t> rom, texture;
static float positions[SM64_GEO_MAX_TRIANGLES*9], normals[SM64_GEO_MAX_TRIANGLES*9];
static float colors[SM64_GEO_MAX_TRIANGLES*9], uvs[SM64_GEO_MAX_TRIANGLES*6];
static SM64MarioGeometryBuffers geometry{positions,normals,colors,uvs,0};
static SM64MarioState state{};
static IDirect3DTexture9* marioTexture=nullptr;
static HWND gameWindow;
static bool keys[256]{};
static LARGE_INTEGER frequency{}, lastTime{};
static double accumulator=0;
static uint64_t tickCount=0;
static float scale=7.5f;
static float footOffset=0,groundHeight=0;
static unsigned shadowTrianglesLast=0;
static HWAVEOUT audioDevice=nullptr;
struct AudioBlock {WAVEHDR header{};int16_t samples[2176]{};bool prepared=false,queued=false;};
static AudioBlock audioBlocks[5];
static bool audioPaused=true;
static ULONGLONG dropUntil=0;
static bool resumePending=false;
struct SceneSnapshot {Vec position{};float yaw=0;uint16_t room=0;uint8_t chapter=0;uint32_t scenario[8]{},locks[8]{};uint64_t collision=0;bool valid=false;};
static SceneSnapshot lastPlayable{},pendingScene{};
static bool hasGround=false,combatReady=false;
using NativeDamageFn=int(__cdecl*)(uint8_t*,int,int,int);
using DamageInfoFn=void(__fastcall*)(void*,void*,int,int,int,const Vec*,float,void*);
using EnemyHitFn=void(__cdecl*)(void*,uint8_t*,const Vec*,const Vec*);
static NativeDamageFn nativeDamage=nullptr;
static DamageInfoFn setDamageInfo=nullptr;
static EnemyHitFn originalEnemyHit=nullptr;
static ULONGLONG hurtUntil=0;
static uint8_t oldHurtbox[0x34]{};
struct EnemyCooldown{uint8_t* enemy;ULONGLONG until;int hpBefore;bool reported;};
static std::vector<EnemyCooldown> enemyCooldowns;
static void __cdecl HookEnemyHit(void*,uint8_t*,const Vec*,const Vec*);
static int __cdecl HookNativeDamage(uint8_t*,int,int,int);
static float cameraYaw=0,cameraPitch=.2730087f,cameraDistance=2500;
static Vec cameraEye{},cameraTarget{};
static bool cameraReady=false,cameraHookReady=false,inputHookReady=false;
static std::vector<MarioCamera::Triangle> cameraTriangles;
static uint8_t* cameraControl=nullptr,*cameraSmooth=nullptr;
using CameraMoveFn=void(__fastcall*)(void*,void*);
static CameraMoveFn originalCameraMove=nullptr;
static void(__cdecl* originalPadRead)()=nullptr;
static uint64_t *gameKeyOn=nullptr,*gameKeyTrigger=nullptr;
static DWORD(WINAPI* getPadState)(DWORD,XINPUT_STATE*)=nullptr;
static DWORD(WINAPI* setPadState)(DWORD,XINPUT_VIBRATION*)=nullptr;
static DWORD padIndex=MAXDWORD;
static WORD lastPadButtons=0;
static ULONGLONG vibrationUntil=0;
static bool overlayScene=false;
static WNDPROC originalWndProc=nullptr;
static float mouseX=0,mouseY=0;
static bool rawMouse=false,mousePointValid=false;
static POINT mousePoint{};
static float cameraDelta=1.f/30;
static uint32_t cameraCollisionCount=0;
static float oldSmoothRatio=.1f;
static bool padStartEdge=false;
static bool padMapEdge=false;
static bool consumeGameplayInput=false;
static void Frame(IDirect3DDevice9*);
static void __fastcall HookCameraMove(void*,void*);
static void __cdecl HookPadRead();
static void SyncProxy(uint8_t*,Vec);

static bool Pad(XINPUT_STATE& pad){
 if(!getPadState)return false;
 if(padIndex!=MAXDWORD&&getPadState(padIndex,&pad)==ERROR_SUCCESS)return true;
 padIndex=MAXDWORD;lastPadButtons=0;
 for(DWORD n=0;n<4;++n)if(getPadState(n,&pad)==ERROR_SUCCESS){padIndex=n;return true;}
 return false;
}
static void StopVibration(){if(setPadState&&padIndex!=MAXDWORD){XINPUT_VIBRATION zero{};setPadState(padIndex,&zero);}vibrationUntil=0;}
static LRESULT CALLBACK HookWndProc(HWND window,UINT msg,WPARAM wparam,LPARAM lparam){
 if(active&&GetForegroundWindow()==window){
  if(msg==WM_INPUT){RAWINPUT input{};UINT bytes=sizeof input;
   if(GetRawInputData((HRAWINPUT)lparam,RID_INPUT,&input,&bytes,sizeof(RAWINPUTHEADER))!=(UINT)-1&&input.header.dwType==RIM_TYPEMOUSE&&!(input.data.mouse.usFlags&MOUSE_MOVE_ABSOLUTE)){
    mouseX+=(float)input.data.mouse.lLastX;mouseY+=(float)input.data.mouse.lLastY;rawMouse=true;
   }
  }else if(msg==WM_MOUSEMOVE&&!rawMouse){POINT now{(SHORT)LOWORD(lparam),(SHORT)HIWORD(lparam)};RECT rect{};GetClientRect(window,&rect);
   if(mousePointValid){float dx=(float)(now.x-mousePoint.x),dy=(float)(now.y-mousePoint.y);
    bool recentered=now.x==(rect.right-rect.left)/2&&now.y==(rect.bottom-rect.top)/2;
    if(!recentered&&fabsf(dx)<200&&fabsf(dy)<200){mouseX+=dx;mouseY+=dy;}
   }mousePoint=now;mousePointValid=true;
  }
 }
 return CallWindowProcW(originalWndProc,window,msg,wparam,lparam);
}

static void Log(const char* msg) { if(logFile){fprintf(logFile,"%s\n",msg);fflush(logFile);} }
static bool Readable(const void* p,size_t len) {
 if(!p || !len)return false;
 uintptr_t at=(uintptr_t)p, end=at+len; if(end<at)return false;
 while(at<end){MEMORY_BASIC_INFORMATION m{};if(!VirtualQuery((void*)at,&m,sizeof m)||m.State!=MEM_COMMIT || (m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;uintptr_t next=(uintptr_t)m.BaseAddress+m.RegionSize;if(next<=at)return false;at=next;}
 return true;
}
template<class T> static T& Field(uint8_t* p,size_t off){return *reinterpret_cast<T*>(p+off);}
static std::vector<int> Parse(const char* s) {
 std::vector<int> v; while(*s){if(*s==' '){++s;continue;}if(*s=='?'){v.push_back(-1);++s;}else{char b[3]={s[0],s[1],0};v.push_back(strtoul(b,nullptr,16));s+=2;}}return v;
}
static uintptr_t Resolve(const char* pattern,size_t operand) {
 auto pat=Parse(pattern);auto base=(uint8_t*)GetModuleHandleW(nullptr);
 auto dos=(IMAGE_DOS_HEADER*)base;auto nt=(IMAGE_NT_HEADERS*)(base+dos->e_lfanew);
 auto sec=IMAGE_FIRST_SECTION(nt);uintptr_t result=0;size_t matches=0;
 for(unsigned n=0;n<nt->FileHeader.NumberOfSections;++n){if(!(sec[n].Characteristics&IMAGE_SCN_MEM_EXECUTE))continue;
  auto p=base+sec[n].VirtualAddress;size_t size=sec[n].Misc.VirtualSize;
  for(size_t i=0;i+pat.size()<=size;++i){bool ok=true;for(size_t j=0;j<pat.size();++j)if(pat[j]>=0&&p[i+j]!=pat[j]){ok=false;break;}
   if(ok){uintptr_t value;memcpy(&value,p+i+operand,4);if(result && value!=result){Log("Signature ambiguous: module disabled.");return 0;}result=value;++matches;}}
 }
 char line[160];snprintf(line,sizeof line,"Signature operand=%zu matches=%zu result=%p",operand,matches,(void*)result);Log(line);return result;
}
static uint8_t* FindUnique(const char* pattern){auto pat=Parse(pattern);auto base=(uint8_t*)GetModuleHandleW(nullptr);auto nt=(IMAGE_NT_HEADERS*)(base+((IMAGE_DOS_HEADER*)base)->e_lfanew);auto sec=IMAGE_FIRST_SECTION(nt);uint8_t* result=nullptr;
 for(unsigned n=0;n<nt->FileHeader.NumberOfSections;++n){if(!(sec[n].Characteristics&IMAGE_SCN_MEM_EXECUTE))continue;auto p=base+sec[n].VirtualAddress;for(size_t i=0;i+pat.size()<=sec[n].Misc.VirtualSize;++i){bool match=true;for(size_t j=0;j<pat.size();++j)if(pat[j]>=0&&p[i+j]!=pat[j]){match=false;break;}if(match){if(result)return nullptr;result=p+i;}}}return result;
}
static uint8_t* CallTarget(uint8_t* instruction){if(!Readable(instruction,5)||(instruction[0]!=0xe8&&instruction[0]!=0xe9))return nullptr;return instruction+5+*(int32_t*)(instruction+1);}
static bool HookBranch(uint8_t* instruction,void* hook){
 if(!CallTarget(instruction))return false;DWORD old=0;if(!VirtualProtect(instruction,5,PAGE_EXECUTE_READWRITE,&old))return false;
 *(int32_t*)(instruction+1)=(uint8_t*)hook-instruction-5;VirtualProtect(instruction,5,old,&old);FlushInstructionCache(GetCurrentProcess(),instruction,5);return true;
}
static uint8_t* FindJumpThunk(uint8_t* function){
 auto base=(uint8_t*)GetModuleHandleW(nullptr);auto nt=(IMAGE_NT_HEADERS*)(base+((IMAGE_DOS_HEADER*)base)->e_lfanew);auto sec=IMAGE_FIRST_SECTION(nt);uint8_t* result=nullptr;
 for(unsigned n=0;n<nt->FileHeader.NumberOfSections;++n){if(!(sec[n].Characteristics&IMAGE_SCN_MEM_EXECUTE))continue;auto p=base+sec[n].VirtualAddress;
  for(size_t i=0;i+5<=sec[n].Misc.VirtualSize;++i)if(p[i]==0xe9&&CallTarget(p+i)==function){if(result)return nullptr;result=p+i;}
 }return result;
}
static void SetupAudio(){
 sm64_audio_init(rom.data());sm64_set_sound_volume(.8f);
 WAVEFORMATEX format{};format.wFormatTag=WAVE_FORMAT_PCM;format.nChannels=2;format.nSamplesPerSec=32000;
 format.wBitsPerSample=16;format.nBlockAlign=4;format.nAvgBytesPerSec=128000;
 auto result=waveOutOpen(&audioDevice,WAVE_MAPPER,&format,0,0,CALLBACK_NULL);
 char line[120];snprintf(line,sizeof line,"Original SM64 ROM audio: WinMM stereo PCM 32000 Hz open=%u",result);Log(line);
}
static void PauseAudio(){if(audioDevice&&!audioPaused){waveOutReset(audioDevice);for(auto& b:audioBlocks)b.queued=false;audioPaused=true;}}
static void PumpAudio(){
 if(!audioDevice)return;audioPaused=false;unsigned queued=0;
 for(auto& b:audioBlocks)if(b.queued&&!(b.header.dwFlags&WHDR_DONE))queued+=b.header.dwBufferLength/4;
 for(auto& b:audioBlocks){if(queued>=1600)break;if(b.queued&&!(b.header.dwFlags&WHDR_DONE))continue;
  unsigned frames=sm64_audio_tick(queued,1600,b.samples)*2;if(!frames||frames>1088)break;
  if(!b.prepared){b.header.lpData=(LPSTR)b.samples;b.header.dwBufferLength=sizeof b.samples;
   if(waveOutPrepareHeader(audioDevice,&b.header,sizeof b.header)!=MMSYSERR_NOERROR){Log("SM64 audio buffer preparation failed.");break;}b.prepared=true;
  }
  b.header.dwBufferLength=frames*4;
  if(waveOutWrite(audioDevice,&b.header,sizeof b.header)!=MMSYSERR_NOERROR){Log("SM64 audio playback failed.");break;}
  b.queued=true;queued+=frames;
 }
}
static uint64_t CollisionFingerprint(){
 if(!Readable(satMgr,0x20))return 0;auto array=Field<uint8_t*>(satMgr,4);auto count=Field<uint32_t>(satMgr,8),stride=Field<uint32_t>(satMgr,12);
 if(count>4096||stride!=0xc0||!Readable(array,(size_t)count*stride))return 0;
 uint64_t hash=1469598103934665603ull;auto add=[&](uint32_t v){hash^=v;hash*=1099511628211ull;};
 for(unsigned i=0;i<count;++i){auto sat=array+i*stride;if((Field<uint32_t>(sat,4)&0x201)!=1)continue;
  add(i);add(sat[0x2a]&4);if(!(sat[0x2a]&4))continue;add(Field<uint16_t>(sat,0x1e));
  for(unsigned j=0;j<12;++j)add(Field<uint32_t>(sat,0x60+j*4));
 }return hash;
}
static SceneSnapshot Snapshot(uint8_t* g,Vec position,float yaw){
 SceneSnapshot s{};if(!Readable(g,0x530c))return s;s.position=position;s.yaw=yaw;s.room=Field<uint16_t>(g,0x28);s.chapter=g[0x4f9a];
 memcpy(s.scenario,g+0x52cc,32);memcpy(s.locks,g+0x52ec,32);s.collision=CollisionFingerprint();s.valid=true;return s;
}
static bool Cinematic(uint8_t* g){return Readable(g,0x5020)&&g[0x20]!=6&&(g[0x20]!=3||(Field<uint32_t>(g,0x501c)&0x14001000));}
static void SetupCombat(){
 // Narrow the SDK's generic manager pattern: other effect managers share its prefix.
 emMgr=(uint8_t*)Resolve("81 E1 01 02 00 00 83 F9 01 75 ? 50 B9 ? ? ? ? E8 ? ? ? ? 89 BE 10 06 00 00 C6 86 F0 07 00 00 00",13);
 auto hit=FindUnique("55 8B EC 83 EC 20 A1 ? ? ? ? 33 C5 89 45 FC 8B 4D 14");
 auto hp=FindUnique("55 8B EC 53 56 57 E8 ? ? ? ? 0F B6 F0 C1 E6 08 E8 ? ? ? ? 8B 4D 10 8B 7D 0C");
 auto info=FindUnique("55 8B EC 8A 45 08 D9 EE 0C 01 56 8B F1 8A 4D 0C D9 1E D9 45 18 88 46 04");
 auto thunk=hit?FindJumpThunk(hit):nullptr;
 auto hpThunk=hp?FindJumpThunk(hp):nullptr;
 if(thunk&&hpThunk&&hp&&info&&Readable(emMgr,0x20)){
  nativeDamage=(NativeDamageFn)hp;setDamageInfo=(DamageInfoFn)info;originalEnemyHit=(EnemyHitFn)hit;
  combatReady=HookBranch(thunk,(void*)HookEnemyHit)&&HookBranch(hpThunk,(void*)HookNativeDamage);
 }
 Log(combatReady?"Combat ready: native enemy HP / damage-info and EmAtkSetDamagePL hook.":"Combat signatures incomplete: Mario activation refused.");
}
static void SetupCamera(){
 cameraControl=(uint8_t*)Resolve("D9 EE B9 ? ? ? ? D9 9E A4 00 00 00 E8 ? ? ? ? D9 EE",3);
 cameraSmooth=(uint8_t*)Resolve("56 B9 ? ? ? ? E8 ? ? ? ? 8D 53 60",2);
 auto move=FindUnique("55 8B EC A1 ? ? ? ? 83 EC 10 F7 80 1C 50 00 00 00 00 04 00 53 8B D9");
 auto thunk=move?FindJumpThunk(move):nullptr;
 if(thunk&&Readable(cameraControl,0x788)&&Readable(cameraSmooth,0x150)){
  originalCameraMove=(CameraMoveFn)move;cameraHookReady=HookBranch(thunk,(void*)HookCameraMove);
 }
 Log(cameraHookReady?"CameraControl::Move hooked: Leon camera bypassed only while Mario is active.":"Camera manager hook failed; activation will be refused.");
 gameKeyOn=(uint64_t*)Resolve("A1 ? ? ? ? 33 C9 83 E0 ? 83 3D",1);
 gameKeyTrigger=(uint64_t*)Resolve("A1 ? ? ? ? 25 ? ? ? ? 0B C1 74 ? 88 0D",1);
 auto padSite=FindUnique("E8 ? ? ? ? E8 ? ? ? ? 68 ? ? ? ? 6A 04 E8 ? ? ? ? 83 C4 18 E8 ? ? ? ? E8 ? ? ? ? A1");
 auto padThunk=padSite?CallTarget(padSite):nullptr;
 if(padThunk&&padThunk[0]==0xe9&&Readable(gameKeyOn,8)&&Readable(gameKeyTrigger,8)){
  originalPadRead=(decltype(originalPadRead))CallTarget(padThunk);inputHookReady=HookBranch(padThunk,(void*)HookPadRead);
 }
 Log(inputHookReady?"PadRead hooked: XInput and keyboard sampled once per game tick.":"PadRead hook failed; activation will be refused.");
 wchar_t system[MAX_PATH];GetSystemDirectoryW(system,MAX_PATH);
 // Prefer the version imported by RE4, including Steam's controller routing.
 for(auto name:{L"xinput1_3.dll",L"xinput1_4.dll",L"xinput9_1_0.dll"}){std::wstring path=system;path+=L"\\";path+=name;
  auto module=LoadLibraryW(path.c_str());if(module){getPadState=(decltype(getPadState))GetProcAddress(module,"XInputGetState");setPadState=(decltype(setPadState))GetProcAddress(module,"XInputSetState");
   if(getPadState){char line[140];snprintf(line,sizeof line,"XInput backend=%ls vibration=%d",name,setPadState!=nullptr);Log(line);break;}
  }
 }
}
static void SetupDoors(){
 auto set=FindUnique("55 8B EC 8A 41 40 3C 08 0F 83 ? ? ? ? 0F B6 D0 8D 14 52 56 8D 74 D1 44");
 auto button=FindUnique("55 8B EC A1 ? ? ? ? 8B 0D ? ? ? ? 25 00 02 CF 00 81 E1 00 00 05 00 83 EC 08");
 auto setThunk=set?FindJumpThunk(set):nullptr;auto buttonThunk=button?FindJumpThunk(button):nullptr;
 if(setThunk&&buttonThunk){originalActionSet=(ActionSetFn)set;originalActionButton=(ActionButtonFn)button;doorHookReady=HookBranch(setThunk,(void*)HookActionSet)&&HookBranch(buttonThunk,(void*)HookActionButton);}
 Log(doorHookReady?"Door hooks ready: native OPEN prompts require Mario facing the door and walking into it.":"Door signatures unavailable: door assistance disabled.");
}
static void Prepare() {
 wchar_t path[MAX_PATH];GetModuleFileNameW(selfModule,path,MAX_PATH);modDir=path;modDir=modDir.substr(0,modDir.find_last_of(L"\\/"));
 logFile=_wfopen((modDir+L"\\re4-mario.log").c_str(),L"w");Log("RE4 Mario prototype 0.7.1 RB-only controller toggle; LB native knife (32-bit)");
 globalPtr=(uint8_t**)Resolve("A1 ? ? ? ? B9 FF FF FF 7F 21 48 ? A1",1);
 playerPtr=(uint8_t**)Resolve("A1 ? ? ? ? D8 CC D8 C9 D8 CA D9 5D ? D9 45 ?",1);
 satMgr=(uint8_t*)Resolve("8D 8E B4 02 00 00 E8 ? ? ? ? 6A 00 56 B9",15);
 eatMgr=(uint8_t*)Resolve("6A 00 53 56 50 51 B9 ? ? ? ? E8",7);
 compatible=Readable(globalPtr,4)&&Readable(playerPtr,4)&&Readable(satMgr,0x20)&&Readable(eatMgr,0x20);
 if(!compatible){Log("Unsupported game signatures. No game state will be changed.");return;}
 auto file=_wfopen((modDir+L"\\mario64.z64").c_str(),L"rb");if(!file){Log("Missing mario64.z64; module disabled.");compatible=false;return;}
 fseek(file,0,SEEK_END);long len=ftell(file);rewind(file);if(len!=8388608){fclose(file);compatible=false;Log("ROM length invalid.");return;}
 rom.resize(len);if(fread(rom.data(),1,len,file)!=(size_t)len){fclose(file);compatible=false;return;}fclose(file);
 const uint8_t magic[]={0x80,0x37,0x12,0x40};if(memcmp(rom.data(),magic,4) || rom[0x3e]!='E'){Log("ROM must be USA big-endian z64.");compatible=false;return;}
 texture.resize(SM64_TEXTURE_WIDTH*SM64_TEXTURE_HEIGHT*4);sm64_global_init(rom.data(),texture.data());initialized=true;
 QueryPerformanceFrequency(&frequency);QueryPerformanceCounter(&lastTime);Log("Ready. RB toggles Mario/Leon. F6 enables Mario. LB retains native Leon knife control. F7/F8 returns Leon. Y opens native map without disabling Mario.");
 SetupCamera();SetupCombat();SetupAudio();SetupDoors();
}
static bool Pressed(int k){bool now=GetAsyncKeyState(k)&0x8000;bool pressed=now&&!keys[k];keys[k]=now;return pressed;}
static bool Down(int k){return (GetAsyncKeyState(k)&0x8000)!=0;}
static Vec ToSM(Vec v){return {(v.x-origin.x)/scale,(v.y-origin.y)/scale,(v.z-origin.z)/scale};}
static Vec ToRE(Vec v){return {v.x*scale+origin.x,v.y*scale+origin.y,v.z*scale+origin.z};}
static bool Enemy(uint8_t* e){
 if(!Readable(e,0x408)||(Field<uint32_t>(e,4)&0x201)!=1||e[0xfc]==0||e[0xfc]>=3||Field<int16_t>(e,0x324)<=0)return false;
 unsigned id=e[0x100];return id>0x10&&id<0x4f&&id!=0x2a&&id!=0x3b&&id!=0x3d&&id!=0x4e;
}
static float EnemyRadius(uint8_t* e){float r=Field<float>(e,0x35c);return std::isfinite(r)&&r>=80&&r<=1500?r:260.f;}
static float EnemyHeight(uint8_t* e){float h=Field<float>(e,0x360);return std::isfinite(h)&&h>=300&&h<=5000?h:1700.f;}
static int __cdecl HookNativeDamage(uint8_t* target,int damage,int random,int flags){
 MarioGuard guard;
 if(!active||target!=ownedPlayer||!Readable(ownedGlobal,0x4fbc))return nativeDamage(target,damage,random,flags);
 if(GetTickCount64()<hurtUntil||state.invincTimer>0)return Field<int16_t>(ownedGlobal,0x4fb4);
 int before=Field<int16_t>(ownedGlobal,0x4fb4),after=nativeDamage(target,damage,random,flags);
 if(after>=before||ownedGlobal[0x20]!=3)return after;
 Vec mario=ToRE({state.position[0],state.position[1],state.position[2]});Vec source=MarioCamera::Add(mario,{sinf(state.faceAngle)*500,0,cosf(state.faceAngle)*500});
 if(Readable(emMgr,0x20)){auto array=Field<uint8_t*>(emMgr,4);auto count=Field<uint32_t>(emMgr,8),stride=Field<uint32_t>(emMgr,12);float closest=5000;
  if(count<=512&&stride>=0x408&&stride<=0x10000&&Readable(array,(size_t)count*stride))for(unsigned i=0;i<count;++i){auto e=array+i*stride;if(!Enemy(e))continue;Vec point=Field<Vec>(e,0x94);float distance=MarioCamera::Length(MarioCamera::Sub(point,mario));if(distance<closest){closest=distance;source=point;}}
 }
 Vec from=ToSM(source);sm64_mario_take_damage(marioId,damage>=500?2:1,0,from.x,from.y,from.z);sm64_set_mario_invincibility(marioId,30);hurtUntil=GetTickCount64()+1000;
 if(setPadState&&padIndex!=MAXDWORD){XINPUT_VIBRATION vibration{8000,12000};setPadState(padIndex,&vibration);vibrationUntil=GetTickCount64()+140;}
 char line[180];snprintf(line,sizeof line,"Native attack hit Mario: HP %d -> %d knockback=yes",before,after);Log(line);return after;
}
static void __cdecl HookEnemyHit(void* yarare,uint8_t* attack,const Vec* impact,const Vec* source){
 MarioGuard guard;
 if(!active){originalEnemyHit(yarare,attack,impact,source);return;}
 if(!Readable(ownedGlobal,0x4fbc)||ownedGlobal[0x20]!=3||!Readable(attack,12)||!Readable(impact,sizeof(Vec))||!Readable(source,sizeof(Vec)))return;
 // Native collision has already accepted Leon's complete hitbox. Do not shrink it.
 auto now=GetTickCount64();if(now<hurtUntil||state.invincTimer>0)return;
 int damage=Field<uint16_t>(attack,8);if(damage<=0)return;
 int before=Field<int16_t>(ownedGlobal,0x4fb4);nativeDamage(ownedPlayer,damage,0,(attack[10]&4)?1:0);
 if(attack[10]&8)Field<int16_t>(ownedGlobal,0x4fb4)=0;
 int after=Field<int16_t>(ownedGlobal,0x4fb4);
 if(after>=before)return;hurtUntil=now+1000;
 Vec from=ToSM(*source);sm64_mario_take_damage(marioId,damage>=500?2:1,0,from.x,from.y,from.z);sm64_set_mario_invincibility(marioId,30);
 if(setPadState&&padIndex!=MAXDWORD){XINPUT_VIBRATION vibration{8000,12000};setPadState(padIndex,&vibration);vibrationUntil=now+140;}
 char line[220];snprintf(line,sizeof line,"Enemy hit Mario: native HP %d -> %d damage=%d knockback=yes",before,after,damage);Log(line);
 // Let RE4's ordinary death path own a lethal hit when Leon is restored next frame.
 if(after<=0)originalEnemyHit(yarare,attack,impact,source);
}
static void CombatTick(){
 if(!combatReady||!Readable(emMgr,0x20))return;
 auto array=Field<uint8_t*>(emMgr,4);auto count=Field<uint32_t>(emMgr,8),stride=Field<uint32_t>(emMgr,12);
 if(count>512||stride<0x408||stride>0x10000||!Readable(array,(size_t)count*stride))return;
 auto now=GetTickCount64();
 for(auto& c:enemyCooldowns)if(!c.reported&&Readable(c.enemy,0x408)&&Field<int16_t>(c.enemy,0x324)<c.hpBefore){
  char line[180];snprintf(line,sizeof line,"Native enemy reaction applied: id=%02x HP %d -> %d",c.enemy[0x100],c.hpBefore,Field<int16_t>(c.enemy,0x324));Log(line);c.reported=true;
 }
 enemyCooldowns.erase(std::remove_if(enemyCooldowns.begin(),enemyCooldowns.end(),[&](const EnemyCooldown& c){return c.until<=now;}),enemyCooldowns.end());
 Vec mario=ToRE({state.position[0],state.position[1],state.position[2]});
 for(unsigned n=0;n<count;++n){auto e=array+n*stride;if(!Enemy(e))continue;Vec enemy=Field<Vec>(e,0x94);
  if(!std::isfinite(enemy.x)||!std::isfinite(enemy.y)||!std::isfinite(enemy.z))continue;
  float radius=EnemyRadius(e),height=EnemyHeight(e),dx=mario.x-enemy.x,dz=mario.z-enemy.z,distance=hypotf(dx,dz);
  bool overlap=mario.y<enemy.y+height&&mario.y+1100>enemy.y;
  bool cooling=std::any_of(enemyCooldowns.begin(),enemyCooldowns.end(),[&](const EnemyCooldown& c){return c.enemy==e;});
  if(overlap&&distance<radius+500&&!cooling&&state.health>0x100){
   // libsm64 checks the active attack animation and its facing cone, not just held X/B.
   Vec target=ToSM(enemy);bool fromAbove=(state.action&0x800)&&state.velocity[1]<0&&mario.y>=enemy.y+height-250;
   bool bodyAttack=!(state.action&0x800)||(state.action&0x00800000);
   if((fromAbove||bodyAttack)&&sm64_mario_attack(marioId,target.x,target.y,target.z,height/scale)){
    int before=Field<int16_t>(e,0x324);
    // Wep 0x14 is the native kick damage slot; native enemy AI decides flinch/death/drop.
    setDamageInfo(e+0x328,nullptr,0,10,0x14,&mario,distance,e+0x344);
    // The native damage reaction applies HP loss itself; do not subtract it twice.
    enemyCooldowns.push_back({e,now+450,before,false});char line[180];snprintf(line,sizeof line,"Mario hit enemy id=%02x HP before=%d native kick queued (single damage)",e[0x100],before);Log(line);
   }
  }
  // Separate overlapping cylinders without teleporting through world geometry.
  if(overlap&&distance<radius+210){
   Vec direction=distance>.1f?Vec{dx/distance,0,dz/distance}:Vec{sinf(state.faceAngle),0,cosf(state.faceAngle)};
   Vec candidate=MarioCamera::Add(mario,MarioCamera::Mul(direction,std::min(radius+210-distance,120.f)));
   if(MarioCamera::RayWorld(MarioCamera::Add(mario,{0,400,0}),MarioCamera::Add(candidate,{0,400,0}),cameraTriangles)>=1){
    Vec moved=ToSM(candidate);SM64WallCollisionData wall{};wall.x=moved.x;wall.y=moved.y;wall.z=moved.z;wall.offsetY=60;wall.radius=28;
    sm64_surface_find_wall_collisions(&wall);sm64_set_mario_position(marioId,wall.x,wall.y,wall.z);
    Vec delta={wall.x-state.position[0],wall.y-state.position[1],wall.z-state.position[2]};
    for(unsigned v=0;v<geometry.numTrianglesUsed*3;++v){positions[v*3]+=delta.x;positions[v*3+1]+=delta.y;positions[v*3+2]+=delta.z;}
    state.position[0]=wall.x;state.position[1]=wall.y;state.position[2]=wall.z;mario=ToRE({wall.x,wall.y,wall.z});
   }
  }
 }
}
static void UpdateGround(){
 hasGround=false;footOffset=0;if(!geometry.numTrianglesUsed)return;
 SM64FloorCollisionData* floor=nullptr;float y=sm64_surface_find_floor_height_and_data(state.position[0],state.position[1]+100,state.position[2],&floor);
 if(!floor||!std::isfinite(y)||y<-10000)return;hasGround=true;groundHeight=y;
 // Anchor the lowest shoe vertex on grounded frames. Airborne poses retain their height.
 if(!(state.action&0x800)&&fabsf(state.position[1]-y)<15){float lowest=1e9f;
  for(unsigned v=0;v<geometry.numTrianglesUsed*3;++v)lowest=std::min(lowest,positions[v*3+1]);
  footOffset=std::clamp(y-lowest,-15.f,15.f);
 }
}
static Vec Transform(float* m,Vec v){return {m[0]*v.x+m[1]*v.y+m[2]*v.z+m[3],m[4]*v.x+m[5]*v.y+m[6]*v.z+m[7],m[8]*v.x+m[9]*v.y+m[10]*v.z+m[11]};}
static void Collect(uint8_t* manager,std::vector<SM64Surface>& out) {
 if(!Readable(manager,0x20))return;
 auto array=Field<uint8_t*>(manager,4);auto count=Field<uint32_t>(manager,8);auto stride=Field<uint32_t>(manager,12);
 if(count>4096 || stride!=0xc0 || !Readable(array,(size_t)count*stride))return;
 for(uint32_t n=0;n<count;++n){auto s=array+n*stride;
  if((Field<uint32_t>(s,4)&0x201)!=1 || !(s[0x2a]&4))continue;
  auto vertices=Field<Vec*>(s,0xc);auto polys=Field<uint16_t*>(s,0x18);auto vc=Field<uint16_t>(s,0x1c);auto pc=Field<uint16_t>(s,0x1e);
  if(!vc || !pc || !Readable(vertices,(size_t)vc*sizeof(Vec)) || !Readable(polys,(size_t)pc*20))continue;
  for(unsigned i=0;i<pc;++i){SM64Surface surf{};bool valid=true;for(int j=0;j<3;++j){auto index=polys[i*10+j];if(index>=vc){valid=false;break;}Vec v=ToSM(Transform((float*)(s+0x60),vertices[index]));
    if(!std::isfinite(v.x)||!std::isfinite(v.y)||!std::isfinite(v.z)||fabs(v.x)>30000||fabs(v.y)>30000||fabs(v.z)>30000){valid=false;break;}
    surf.vertices[j][0]=(int32_t)lround(v.x);surf.vertices[j][1]=(int32_t)lround(v.y);surf.vertices[j][2]=(int32_t)lround(v.z);}
   if(valid && out.size()<200000)out.push_back(surf);}
 }
}
static void SyncProxy(uint8_t* p,Vec pos){
 // Native wall/attack tests also read cParts world coordinates. Keep those following
 // the proxy while leaving their local bone transforms untouched for Leon's return.
 Vec oldPosition=Field<Vec>(p,0x94);float previousYaw=atan2f(Field<float>(p,0xc+8),Field<float>(p,0xc+40));float yawDelta=state.faceAngle-previousYaw;
 float sn=sinf(yawDelta),cs=cosf(yawDelta);auto rotate=[&](Vec v){return Vec{cs*v.x+sn*v.z,v.y,-sn*v.x+cs*v.z};};
 auto move=[&](Vec v){return MarioCamera::Add(pos,rotate(MarioCamera::Sub(v,oldPosition)));};auto part=Field<uint8_t*>(p,0xf4);
 for(unsigned i=0;i<128&&Readable(part,0xf8);++i){
  for(auto off:{0x70,0x7c,0x88})Field<Vec>(part,off)=move(Field<Vec>(part,off));
  auto mat=(float*)(part+0xc);Vec translated=move({mat[3],mat[7],mat[11]});
  for(unsigned column=0;column<3;++column){float x=mat[column],z=mat[8+column];mat[column]=cs*x+sn*z;mat[8+column]=-sn*x+cs*z;}
  mat[3]=translated.x;mat[7]=translated.y;mat[11]=translated.z;
  auto next=Field<uint8_t*>(part,0xf4);if(next==part)break;part=next;
 }
 Field<Vec>(p,0x94)=pos;Field<Vec>(p,0x70)=pos;Field<Vec>(p,0x7c)=pos;Field<Vec>(p,0x88)=pos;Field<Vec>(p,0x110)=pos;Field<Vec>(p,0x7f8)=pos;
 Field<Vec>(p,0x104)={0,0,0};Field<Vec>(p,0xa0).y=state.faceAngle;
 for(auto off:{0xc,0x3c,0xc4}){float* mat=(float*)(p+off);float c=cosf(state.faceAngle),s=sinf(state.faceAngle);float yaw[12]={c,0,s,pos.x,0,1,0,pos.y,-s,0,c,pos.z};memcpy(mat,yaw,sizeof yaw);}
 Vec atari=move(Field<Vec>(p,0x2e4));Field<Vec>(p,0x2e4)=atari;Field<Vec>(p,0x2f0)=atari;
}
static bool NativeDoor(int kind,int type,uint8_t* argument){
 if(kind!=0x10)return false;
 if(type==0)return Readable(argument,0x104)&&argument[0x100]==0x51;
 return type==2&&Readable(argument,0x5c)&&argument[0x35]==1;
}
static bool FacingDoor(int type,uint8_t* argument){
 Vec mario=ToRE({state.position[0],state.position[1],state.position[2]});Vec forward{sinf(state.faceAngle),0,cosf(state.faceAngle)};
 if(type==0){Vec delta=MarioCamera::Sub(mario,Field<Vec>(argument,0x94));float yaw=Field<Vec>(argument,0xa0).y;Vec normal{sinf(yaw),0,cosf(yaw)};
  float side=MarioCamera::Dot(delta,normal),alignment=MarioCamera::Dot(forward,normal);return fabsf(side)<30?fabsf(alignment)>.7071067f:alignment*(side>0?-1.f:1.f)>.7071067f;
 }
 if(argument[0x37]&2){float yaw=(int8_t)argument[0x48]*.034906585f;auto parent=Field<uint8_t*>(argument,0x4c);if(parent&&Readable(parent,0xac)&&!(argument[0x34]&8))yaw+=Field<Vec>(parent,0xa0).y;return cosf(state.faceAngle-yaw)>.7071067f;}
 Vec center{};auto shape=argument[5];if(shape==1){for(unsigned i=0;i<4;++i){center.x+=Field<float>(argument,0x14+i*8)*.25f;center.z+=Field<float>(argument,0x18+i*8)*.25f;}}else if(shape==2||shape==3){center.x=Field<float>(argument,0x14);center.z=Field<float>(argument,0x18);}else return false;
 center.y=mario.y;auto parent=Field<uint8_t*>(argument,0x4c);if(parent&&Readable(parent,0x3c))center=Transform((float*)(parent+0xc),center);
 Vec delta=MarioCamera::Sub(center,mario);delta.y=0;float distance=MarioCamera::Length(delta);return distance<100||MarioCamera::Dot(forward,MarioCamera::Mul(delta,1/distance))>.7071067f;
}
static void __fastcall HookActionSet(void* object,void* unused,int kind,int slot,void* callback,void* argument,int flags,int button,int type,void* model){
 MarioGuard guard;auto arg=(uint8_t*)argument;
 if(active&&NativeDoor(kind,type,arg)){if(!FacingDoor(type,arg))return;flags|=2;}
 originalActionSet(object,unused,kind,slot,callback,argument,flags,button,type,model);
}
static bool __fastcall HookActionButton(void* object,void* unused,uint8_t* work){
 MarioGuard guard;if(!active||!Readable(work,0x18)||!Readable(ownedPlayer,0x814)||!Readable(ownedGlobal,0x174))return originalActionButton(object,unused,work);
 auto arg=Field<uint8_t*>(work,8);int type=work[0xe];if(!NativeDoor(work[0xc],type,arg))return originalActionButton(object,unused,work);
 if(doorNativePending||!doorWalkIntent||GetTickCount64()<doorCooldown||!FacingDoor(type,arg)||(state.action&0x800)||state.health<=0x100)return false;
 doorNativePending=true;doorRoutineBefore=ownedPlayer[0xfc];doorElapsed=0;doorCooldown=GetTickCount64()+1200;
 Field<uint32_t>(ownedGlobal,0x170)&=~0x10000000u;
 Log(type==0?"Mario facing closed door: walking contact accepted; native opening animation delegated with Leon hidden.":"Mario facing room door: walking contact accepted; native locks and room transition retained.");return true;
}
static void Disable() {
 if(!active)return;
 if(Readable(ownedPlayer,0x814) && playerPtr && *playerPtr==ownedPlayer){auto& flags=Field<uint32_t>(ownedPlayer,4);flags=(flags&~0x22u)|oldDrawBits;memcpy(ownedPlayer+0x344,oldHurtbox,sizeof oldHurtbox);}
 if(Readable(ownedGlobal,0x174) && globalPtr && *globalPtr==ownedGlobal && !oldPlayerStop)Field<uint32_t>(ownedGlobal,0x170)&=~0x10000000u;
 if(Readable(cameraSmooth,0x100))Field<float>(cameraSmooth,0xfc)=oldSmoothRatio;
 doorNativePending=false;doorWalkIntent=false;PauseAudio();StopVibration();if(marioId>=0)sm64_mario_delete(marioId);marioId=-1;active=false;cameraReady=false;ownedPlayer=ownedGlobal=nullptr;geometry.numTrianglesUsed=0;mouseX=mouseY=0;enemyCooldowns.clear();hasGround=false;Log("Mario disabled. Original player and camera control restored.");
}
static bool Enable(uint8_t* p,uint8_t* g) {
 if(!cameraHookReady||!inputHookReady||!combatReady||!Readable(g,0x4fbc)){Log("Activation refused: camera/input/combat signatures incomplete.");return false;}
 if(Field<int16_t>(g,0x4fb4)<=0){Log("Activation refused: player is dead.");return false;}
 Disable();recovery=Field<Vec>(p,0x94);origin=recovery;
 std::vector<SM64Surface> surfaces;Collect(satMgr,surfaces);Collect(eatMgr,surfaces);
 char line[180];snprintf(line,sizeof line,"Collision triangles=%zu player=(%.2f %.2f %.2f)",surfaces.size(),origin.x,origin.y,origin.z);Log(line);
 if(surfaces.empty()){Log("No real level collision found. Activation cancelled.");return false;}
 cameraTriangles.clear();cameraTriangles.reserve(surfaces.size());
 for(const auto& surf:surfaces){MarioCamera::Triangle triangle;Vec* points[]={&triangle.a,&triangle.b,&triangle.c};
  for(unsigned i=0;i<3;++i)*points[i]=ToRE({(float)surf.vertices[i][0],(float)surf.vertices[i][1],(float)surf.vertices[i][2]});cameraTriangles.push_back(triangle);
 }
 sm64_static_surfaces_load(surfaces.data(),(uint32_t)surfaces.size());
 float floor=sm64_surface_find_floor_height(0,200,0);snprintf(line,sizeof line,"Floor at spawn %.2f",floor);Log(line);
 if(!std::isfinite(floor)||floor< -10000 || fabs(floor)>500){Log("Spawn has no plausible floor; activation cancelled.");return false;}
 marioId=sm64_mario_create(0,floor+20,0);if(marioId<0){Log("Mario spawn failed.");return false;}
 sm64_set_mario_health(marioId,(int16_t)(0x100+0x780*std::clamp(Field<int16_t>(g,0x4fb4)/(float)std::max(1,(int)Field<int16_t>(g,0x4fb6)),0.f,1.f)));sm64_set_mario_action(marioId,0x0C400201); // ACT_IDLE
 hurtUntil=0;enemyCooldowns.clear();hasGround=false;footOffset=0;
 ownedPlayer=p;ownedGlobal=g;oldDrawBits=Field<uint32_t>(p,4)&0x22;oldPlayerStop=(Field<uint32_t>(g,0x170)&0x10000000)!=0;
 // Keep Leon's complete native hurtbox and its linked body shapes, as requested.
 memcpy(oldHurtbox,p+0x344,sizeof oldHurtbox);
 oldSmoothRatio=Field<float>(cameraSmooth,0xfc);
 currentRoom=Field<uint16_t>(g,0x28);active=true;accumulator=0;QueryPerformanceCounter(&lastTime);
 auto eye=Field<Vec>(g+0x74,0xa4);cameraYaw=atan2f(eye.x-origin.x,eye.z-origin.z);cameraPitch=.2730087f;cameraDistance=2500;cameraReady=false;cameraCollisionCount=0;
 state={};state.position[1]=floor;state.faceAngle=Field<Vec>(p,0xa0).y;sm64_set_mario_faceangle(marioId,state.faceAngle);mouseX=mouseY=0;mousePointValid=false;dropUntil=0;lastPlayable=Snapshot(g,ToRE({0,floor,0}),state.faceAngle);
 Log("Mario active; Space/A jump, F/X/B attack, Ctrl/LT crouch on ground and ground pound in air, RT unused, Y native map, RB toggle Mario/Leon, R/Back recovery; walk into doors facing them.");return true;
}
static void Recover(uint8_t* p,uint8_t* g){Vec saved=recovery;Disable();SyncProxy(p,saved);Enable(p,g);Log("Reset to saved activation point, not the fallen position.");}
static void SuspendForScene(){pendingScene=lastPlayable;resumePending=pendingScene.valid;Disable();Log("Mario suspended for native cinematic/room transition; saved exact world position.");}
static void ResumeAfterScene(uint8_t* p,uint8_t* g){
 auto after=Snapshot(g,Field<Vec>(p,0x94),Field<Vec>(p,0xa0).y);if(!after.valid)return;
 bool progress=after.room!=pendingScene.room||after.chapter!=pendingScene.chapter||memcmp(after.locks,pendingScene.locks,32)||
  MarioMobility::StoryFlagsChanged(pendingScene.scenario,after.scenario)||after.collision!=pendingScene.collision;
 Vec nativePosition=after.position;
 if(!progress){SyncProxy(p,pendingScene.position);Field<Vec>(p,0xa0).y=pendingScene.yaw;}
 if(Enable(p,g)){
  if(!progress){Vec exact=ToSM(pendingScene.position);sm64_set_mario_position(marioId,exact.x,exact.y,exact.z);state.position[0]=exact.x;state.position[1]=exact.y;state.position[2]=exact.z;
   sm64_set_mario_faceangle(marioId,pendingScene.yaw);float floor=sm64_surface_find_floor_height(exact.x,exact.y+100,exact.z);if(fabsf(exact.y-floor)>15)sm64_set_mario_action(marioId,0x0100088c);
  }
  char line[280];snprintf(line,sizeof line,"Cinematic resume: storyProgress=%d saved=(%.1f %.1f %.1f) native=(%.1f %.1f %.1f) chosen=%s",progress,pendingScene.position.x,pendingScene.position.y,pendingScene.position.z,nativePosition.x,nativePosition.y,nativePosition.z,progress?"Leon story endpoint":"exact pre-cinematic position");Log(line);
  resumePending=false;pendingScene={};
 }
}
static void ReturnToLeon(){
 if(active&&Readable(ownedPlayer,0x814)){Vec position=ToRE({state.position[0],state.position[1],state.position[2]});SyncProxy(ownedPlayer,position);
  char line[180];snprintf(line,sizeof line,"Handoff Mario -> Leon at same position (%.1f %.1f %.1f)",position.x,position.y,position.z);Log(line);
 }
 resumePending=false;pendingScene={};Disable();
}
static void TryDrop(const SM64MarioInputs& inputs,Vec previous){
 if((state.action&0x800)||state.health<=0x100||inputs.buttonZ||GetTickCount64()<dropUntil)return;
 float magnitude=hypotf(inputs.stickX,inputs.stickY);if(magnitude<.55f)return;
 Vec direction={sinf(state.faceAngle),0,cosf(state.faceAngle)};
 Vec mario=ToRE({state.position[0],state.position[1],state.position[2]}),before=ToRE(previous);
 // Only assist a blocked edge, not ordinary walking over already traversable terrain.
 if(hypotf(mario.x-before.x,mario.z-before.z)>65)return;
 Vec candidate{};
 auto floor=[&](Vec at){Vec query=ToSM(at);
  SM64SurfaceCollisionData* ceiling=nullptr;float top=sm64_surface_find_ceil(query.x,query.y+130,query.z,&ceiling);if(ceiling&&top<query.y+160)return NAN;
  for(float offset:{30.f,150.f}){SM64WallCollisionData wall{};wall.x=query.x;wall.y=query.y;wall.z=query.z;wall.offsetY=offset;wall.radius=50;
   sm64_surface_find_wall_collisions(&wall);if(hypotf(wall.x-query.x,wall.z-query.z)>5)return NAN;
  }
  float h=sm64_surface_find_floor_height(query.x,query.y+100,query.z);return h<-10000?NAN:ToRE({query.x,h,query.z}).y;
 };
 if(!MarioMobility::FindDrop(mario,direction,cameraTriangles,floor,candidate))return;
 Vec next=ToSM(candidate);SM64SurfaceCollisionData* ceiling=nullptr;float top=sm64_surface_find_ceil(next.x,next.y+130,next.z,&ceiling);
 if(ceiling&&top<next.y+160)return;
 SM64WallCollisionData wall{};wall.x=next.x;wall.y=next.y;wall.z=next.z;wall.offsetY=70;wall.radius=30;
 sm64_surface_find_wall_collisions(&wall);if(hypotf(wall.x-next.x,wall.z-next.z)>5)return;
 Vec delta=MarioCamera::Sub(next,{state.position[0],state.position[1],state.position[2]});
 sm64_set_mario_position(marioId,next.x,next.y,next.z);sm64_set_mario_action(marioId,0x0100088c);sm64_set_mario_velocity(marioId,0,-4,0);
 for(unsigned v=0;v<geometry.numTrianglesUsed*3;++v){positions[v*3]+=delta.x;positions[v*3+1]+=delta.y;positions[v*3+2]+=delta.z;}
 state.position[0]=next.x;state.position[1]=next.y;state.position[2]=next.z;state.action=0x0100088c;dropUntil=GetTickCount64()+1500;
 Log("Automatic ledge descent: lower floor verified; freefall without native action button.");
}
static void SetCamera(uint8_t* camera,Vec eye,Vec target){
 using namespace MarioCamera;
 Vec back=Unit(Sub(eye,target)),right=Unit(Cross({0,1,0},back)),up=Cross(back,right);
 float world[12]={right.x,up.x,back.x,eye.x,right.y,up.y,back.y,eye.y,right.z,up.z,back.z,eye.z};
 float view[12]={right.x,right.y,right.z,-Dot(right,eye),up.x,up.y,up.z,-Dot(up,eye),back.x,back.y,back.z,-Dot(back,eye)};
 memcpy(camera,world,sizeof world);memcpy(camera+0x30,view,sizeof view);
 Field<Vec>(camera,0xa4)=eye;Field<Vec>(camera,0xb0)=target;Field<float>(camera,0xbc)=0;Field<float>(camera,0xc0)=60;
 Field<Vec>(camera,0xc4)=up;Field<Vec>(camera,0xd0)=back;Field<Vec>(camera,0xdc)=right;Field<float>(camera,0xf4)=Length(Sub(eye,target));
 auto projection=(float*)(camera+0x64);float aspect=projection[0]!=0?fabsf(projection[5]/projection[0]):4.f/3;
 if(!std::isfinite(aspect)||aspect<.5f||aspect>4)aspect=4.f/3;
 projection[0]=1.7320508f/aspect;projection[5]=1.7320508f;
}
static void __fastcall HookCameraMove(void* object,void* unused){
 MarioGuard guard;
 if(!active||Cinematic(ownedGlobal)||object!=cameraControl||!Readable(object,0x788)||!Readable(ownedGlobal,0x174)||ownedGlobal[0x20]!=3||(Field<uint32_t>(ownedGlobal,0x170)&0x82000000)){
  if(originalCameraMove)originalCameraMove(object,unused);return;
 }
 using namespace MarioCamera;
 Vec mario=ToRE({state.position[0],state.position[1],state.position[2]});Vec target=Add(mario,{0,800,0});
 // Native RE4 uses millimetres: 2500 behind and 1500 above Mario at default pitch.
 Vec desired=Add(target,{sinf(cameraYaw)*cameraDistance,tanf(cameraPitch)*cameraDistance,cosf(cameraYaw)*cameraDistance});
 Vec allowed=Collide(target,desired,cameraTriangles);bool blocked=Length(Sub(allowed,desired))>1;
 if(blocked)++cameraCollisionCount;
 float alpha=1-std::pow(.9f,std::clamp(cameraDelta,0.f,.1f)*30);
 if(!cameraReady){cameraEye=allowed;cameraTarget=target;cameraReady=true;}
 else {cameraTarget=Lerp(cameraTarget,target,alpha);cameraEye=Lerp(cameraEye,allowed,alpha);}
 // Re-test the interpolated position, so lerp cannot sweep through a wall/corner.
 cameraEye=Collide(target,cameraEye,cameraTriangles);cameraTarget=target;
 auto control=(uint8_t*)object;auto camera=ownedGlobal+0x74;SetCamera(camera,cameraEye,cameraTarget);
 memcpy(control+0x38,camera+0xa4,32);memcpy(control+0x60,camera,0xf8);
 if(Readable(cameraSmooth,0x150)){memcpy(cameraSmooth,camera,0xf8);memcpy(cameraSmooth+0x100,camera+0xa4,32);memcpy(cameraSmooth+0x130,camera+0xa4,32);Field<float>(cameraSmooth,0xfc)=1;}
 static ULONGLONG nextLog=0;auto now=GetTickCount64();if(now>=nextLog){char line[240];
  snprintf(line,sizeof line,"Lakitu eye=(%.1f %.1f %.1f) distance=%.1f desired=%.1f yaw=%.3f fov=60 collision=%u",cameraEye.x,cameraEye.y,cameraEye.z,Length(Sub(cameraEye,target)),cameraDistance,cameraYaw,cameraCollisionCount);Log(line);nextLog=now+2000;
 }
}
static bool drawingNativeDepth=false;
struct Vertex {float x,y,z,rhw;DWORD color;float u,v;};
static bool Project(Vec world,uint8_t* g,const D3DVIEWPORT9& vp,Vertex& out) {
 auto cam=g+0x74;Vec view=Transform((float*)(cam+0x30),world);auto proj=(float*)(cam+0x64);
 float x=proj[0]*view.x+proj[1]*view.y+proj[2]*view.z+proj[3];
 float y=proj[4]*view.x+proj[5]*view.y+proj[6]*view.z+proj[7];
 float z=proj[8]*view.x+proj[9]*view.y+proj[10]*view.z+proj[11];
 float w=proj[12]*view.x+proj[13]*view.y+proj[14]*view.z+proj[15];
 if(!std::isfinite(w)||w<=1)return false;
 out.x=vp.X+(x/w+1)*vp.Width*.5f;out.y=vp.Y+(1-y/w)*vp.Height*.5f;
 // RE4's GX projection spans [-1,0]; D3D9 spans [0,1].
 out.z=vp.MinZ+(vp.MaxZ-vp.MinZ)*std::clamp(z/w+1,0.f,1.f);out.rhw=1/w;
 return std::isfinite(out.x)&&std::isfinite(out.y)&&fabs(out.x)<100000&&fabs(out.y)<100000;
}
static void DrawShadow(IDirect3DDevice9* dev,uint8_t* g,const D3DVIEWPORT9& vp){
 shadowTrianglesLast=0;
 if(!hasGround)return;
 Vec center=ToRE({state.position[0],groundHeight+.5f,state.position[2]});
 if(cameraReady&&MarioCamera::RayWorld(cameraEye,center,cameraTriangles)<.998f)return;
 float height=std::max(0.f,state.position[1]-groundHeight),opacity=.62f/(1+height/250);
 float radius=48.f*std::clamp(1-height/1800,.45f,1.f);
 constexpr int segments=24;std::vector<Vertex> verts;verts.reserve(segments*3);
 auto vertex=[&](float x,float z,bool center,Vertex& v){
  SM64FloorCollisionData* floor=nullptr;float y=sm64_surface_find_floor_height_and_data(x,state.position[1]+100,z,&floor);
  if(!floor||!std::isfinite(y)||fabsf(y-groundHeight)>90)return false;
  Vec world=ToRE({x,y+.5f,z});
  if(!Project(world,g,vp,v))return false;v.color=D3DCOLOR_ARGB(center?(unsigned)(opacity*255):0,0,0,0);v.u=v.v=0;return true;
 };
 for(int i=0;i<segments;++i){Vertex tri[3]{};float a=i*6.2831853f/segments,b=(i+1)*6.2831853f/segments;
  if(vertex(state.position[0],state.position[2],true,tri[0])&&
     vertex(state.position[0]+cosf(a)*radius,state.position[2]+sinf(a)*radius,false,tri[1])&&
     vertex(state.position[0]+cosf(b)*radius,state.position[2]+sinf(b)*radius,false,tri[2]))verts.insert(verts.end(),tri,tri+3);
 }
 if(verts.empty())return;
 shadowTrianglesLast=(unsigned)verts.size()/3;
 dev->SetTexture(0,nullptr);dev->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_SELECTARG1);dev->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_DIFFUSE);
 dev->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);dev->SetTextureStageState(0,D3DTSS_ALPHAARG1,D3DTA_DIFFUSE);dev->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_DISABLE);
 dev->DrawPrimitiveUP(D3DPT_TRIANGLELIST,(UINT)verts.size()/3,verts.data(),sizeof(Vertex));
}
static void Draw(IDirect3DDevice9* dev,uint8_t* g) {
 MarioGuard guard;
 if(!geometry.numTrianglesUsed)return;
 if(!marioTexture){if(FAILED(dev->CreateTexture(SM64_TEXTURE_WIDTH,SM64_TEXTURE_HEIGHT,1,0,D3DFMT_A8R8G8B8,D3DPOOL_MANAGED,&marioTexture,nullptr)))return;
  D3DLOCKED_RECT lock;if(FAILED(marioTexture->LockRect(0,&lock,nullptr,0)))return;
  for(unsigned y=0;y<SM64_TEXTURE_HEIGHT;++y){auto dst=(uint8_t*)lock.pBits+y*lock.Pitch;auto src=texture.data()+y*SM64_TEXTURE_WIDTH*4;for(unsigned x=0;x<SM64_TEXTURE_WIDTH;++x){dst[4*x]=src[4*x+2];dst[4*x+1]=src[4*x+1];dst[4*x+2]=src[4*x];dst[4*x+3]=src[4*x+3];}}marioTexture->UnlockRect(0);}
 D3DVIEWPORT9 vp;if(FAILED(dev->GetViewport(&vp)))return;
 std::vector<Vertex> verts;verts.reserve(geometry.numTrianglesUsed*3);
 for(unsigned t=0;t<geometry.numTrianglesUsed;++t){Vertex tri[3];bool valid=true;for(unsigned j=0;j<3;++j){unsigned i=t*3+j;
   Vec p=ToRE({positions[3*i],positions[3*i+1]+footOffset,positions[3*i+2]});if(!Project(p,g,vp,tri[j])){valid=false;break;}
   auto ch=[](float v){return (unsigned)(std::clamp(v,0.f,1.f)*255);};float light=.75f+.25f*std::max(0.f,normals[3*i+1]);
   tri[j].color=D3DCOLOR_ARGB(255,ch(colors[3*i]*light),ch(colors[3*i+1]*light),ch(colors[3*i+2]*light));tri[j].u=uvs[2*i];tri[j].v=uvs[2*i+1];}
  if(valid)verts.insert(verts.end(),tri,tri+3);}
 static uint64_t lastDrawLog=0;
 if(tickCount>=lastDrawLog+150){char line[480];auto cam=g+0x74;auto proj=(float*)(cam+0x64);Vec center=ToRE({state.position[0],state.position[1]+80,state.position[2]});Vec v=Transform((float*)(cam+0x30),center);snprintf(line,sizeof line,"Render viewport=%lux%lu verts=%zu centerView=(%.2f %.2f %.2f) projection=(%.3f %.3f %.3f %.3f) wrow=(%.3f %.3f %.3f %.3f)",vp.Width,vp.Height,verts.size(),v.x,v.y,v.z,proj[0],proj[5],proj[10],proj[11],proj[12],proj[13],proj[14],proj[15]);Log(line);snprintf(line,sizeof line,"Ground visual: scale=%.2f floorValid=%d footCorrection=%.2f shadowTriangles=%u HP=%d/%d",scale,hasGround,footOffset,shadowTrianglesLast,Field<int16_t>(g,0x4fb4),Field<int16_t>(g,0x4fb6));Log(line);lastDrawLog=tickCount;}
 if(verts.empty())return;
 std::vector<size_t> triangleOrder(verts.size()/3);for(size_t t=0;t<triangleOrder.size();++t)triangleOrder[t]=t;
 std::sort(triangleOrder.begin(),triangleOrder.end(),[&](size_t a,size_t b){return verts[a*3].rhw+verts[a*3+1].rhw+verts[a*3+2].rhw < verts[b*3].rhw+verts[b*3+1].rhw+verts[b*3+2].rhw;});
 std::vector<Vertex> sorted;sorted.reserve(verts.size());for(auto t:triangleOrder)sorted.insert(sorted.end(),verts.begin()+t*3,verts.begin()+t*3+3);verts.swap(sorted);
 IDirect3DStateBlock9* block=nullptr;if(FAILED(dev->CreateStateBlock(D3DSBT_ALL,&block)))return;block->Capture();
 dev->SetVertexShader(nullptr);dev->SetPixelShader(nullptr);dev->SetFVF(D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1);
 dev->SetRenderState(D3DRS_CULLMODE,D3DCULL_NONE);dev->SetRenderState(D3DRS_LIGHTING,FALSE);dev->SetRenderState(D3DRS_FOGENABLE,FALSE);
 dev->SetRenderState(D3DRS_ZENABLE,drawingNativeDepth?D3DZB_TRUE:D3DZB_FALSE);dev->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);dev->SetRenderState(D3DRS_ZFUNC,D3DCMP_LESSEQUAL);
 dev->SetRenderState(D3DRS_STENCILENABLE,FALSE);
 dev->SetRenderState(D3DRS_CLIPPLANEENABLE,0);dev->SetRenderState(D3DRS_SRGBWRITEENABLE,FALSE);
 dev->SetRenderState(D3DRS_ALPHABLENDENABLE,TRUE);dev->SetRenderState(D3DRS_SRCBLEND,D3DBLEND_SRCALPHA);dev->SetRenderState(D3DRS_DESTBLEND,D3DBLEND_INVSRCALPHA);
 dev->SetRenderState(D3DRS_ALPHATESTENABLE,TRUE);dev->SetRenderState(D3DRS_ALPHAREF,1);dev->SetRenderState(D3DRS_ALPHAFUNC,D3DCMP_GREATER);
 dev->SetRenderState(D3DRS_COLORWRITEENABLE,15);dev->SetRenderState(D3DRS_SCISSORTESTENABLE,FALSE);
 DrawShadow(dev,g,vp);dev->SetRenderState(D3DRS_ZWRITEENABLE,drawingNativeDepth?TRUE:FALSE);dev->SetTexture(0,marioTexture);
 dev->SetTextureStageState(0,D3DTSS_COLOROP,D3DTOP_BLENDTEXTUREALPHA);dev->SetTextureStageState(0,D3DTSS_COLORARG1,D3DTA_TEXTURE);dev->SetTextureStageState(0,D3DTSS_COLORARG2,D3DTA_DIFFUSE);
 dev->SetTextureStageState(0,D3DTSS_ALPHAOP,D3DTOP_SELECTARG1);dev->SetTextureStageState(0,D3DTSS_ALPHAARG1,D3DTA_DIFFUSE);dev->SetTextureStageState(1,D3DTSS_COLOROP,D3DTOP_DISABLE);
 dev->SetTextureStageState(0,D3DTSS_TEXCOORDINDEX,0);dev->SetTextureStageState(0,D3DTSS_TEXTURETRANSFORMFLAGS,D3DTTFF_DISABLE);
 dev->SetSamplerState(0,D3DSAMP_MINFILTER,D3DTEXF_POINT);dev->SetSamplerState(0,D3DSAMP_MAGFILTER,D3DTEXF_POINT);dev->SetSamplerState(0,D3DSAMP_ADDRESSU,D3DTADDRESS_CLAMP);dev->SetSamplerState(0,D3DSAMP_ADDRESSV,D3DTADDRESS_CLAMP);
 dev->DrawPrimitiveUP(D3DPT_TRIANGLELIST,(UINT)verts.size()/3,verts.data(),sizeof(Vertex));block->Apply();block->Release();
}
static void Frame(IDirect3DDevice9* dev) {
 MarioGuard guard;
 if(!checked){checked=true;Prepare();}if(!compatible||!initialized)return;
 consumeGameplayInput=false;padStartEdge=false;padMapEdge=false;doorWalkIntent=false;
 LARGE_INTEGER now;QueryPerformanceCounter(&now);double elapsed=(double)(now.QuadPart-lastTime.QuadPart)/frequency.QuadPart;lastTime=now;
 float dt=(float)std::clamp(elapsed,0.,.1);cameraDelta=dt;
 XINPUT_STATE pad{};bool hasPad=Pad(pad);WORD padButtons=hasPad?pad.Gamepad.wButtons:0;
 WORD padPressed=padButtons&~lastPadButtons;lastPadButtons=padButtons;
 static DWORD loggedPad=MAXDWORD-1;if(loggedPad!=padIndex){char line[120];snprintf(line,sizeof line,"XInput controller %s slot=%lu",hasPad?"connected":"disconnected",padIndex);Log(line);loggedPad=padIndex;}
 if(vibrationUntil&&GetTickCount64()>=vibrationUntil)StopVibration();
 uint8_t* p=*playerPtr;uint8_t* g=*globalPtr;
 if(!Readable(p,0x814)||!Readable(g,0x530c)){if(active)SuspendForScene();PauseAudio();return;}
 if(g[0x20]==0||g[0x20]==5){resumePending=false;pendingScene={};Disable();return;}
 if(active && (p!=ownedPlayer||g!=ownedGlobal||Field<uint16_t>(g,0x28)!=currentRoom||Cinematic(g)))SuspendForScene();
 DWORD foregroundPid=0;GetWindowThreadProcessId(GetForegroundWindow(),&foregroundPid);
 bool focused=foregroundPid==GetCurrentProcessId();
 bool playable=g[0x20]==3&&!Cinematic(g)&&!(Field<uint32_t>(g,0x170)&0x82000000);
 if(resumePending&&playable&&focused&&Field<int16_t>(g,0x4fb4)>0)ResumeAfterScene(p,g);
 // Poll every edge unconditionally, so focus/menu transitions cannot leave stale keys.
 bool activateKey=Pressed(VK_F6),leon7=Pressed(VK_F7),leon8=Pressed(VK_F8),resetKey=Pressed('R');bool leonKey=leon7||leon8;
 bool attackKey=Down('F');
 static uint8_t previousRoutine=255;static uint16_t previousRoom=0xffff;
 if(g[0x20]!=previousRoutine || Field<uint16_t>(g,0x28)!=previousRoom){char line[180];snprintf(line,sizeof line,"Game state routine=%u room=%04x focused=%d stops=%08x player=%p",g[0x20],Field<uint16_t>(g,0x28),focused,Field<uint32_t>(g,0x170),p);Log(line);previousRoutine=g[0x20];previousRoom=Field<uint16_t>(g,0x28);}
 padStartEdge=focused&&hasPad&&(padPressed&XINPUT_GAMEPAD_START);
 if(focused){
  if(playable&&(padPressed&XINPUT_GAMEPAD_RIGHT_SHOULDER)){
   consumeGameplayInput=true;Log("RB received: toggle Mario/Leon.");
   if(active){ReturnToLeon();return;}else Enable(p,g);
  }
  if(leonKey){consumeGameplayInput=active;ReturnToLeon();return;}
  padMapEdge=active&&g[0x20]==3&&(padPressed&XINPUT_GAMEPAD_Y);
  if(activateKey){
   Log("F6 received.");if(!active&&playable)Enable(p,g);
  }
  if(active&&(resetKey||(padPressed&XINPUT_GAMEPAD_BACK))){Recover(p,g);return;}
 }
 if(!active){PauseAudio();return;}
 if(Readable(g,0x4fbc)&&Field<int16_t>(g,0x4fb4)<=0){Log("Mario HP depleted: returning control to native RE4 death handling.");Disable();return;}
 auto stops=Field<uint32_t>(g,0x170);if(!focused || !playable){PauseAudio();accumulator=0;mouseX=mouseY=0;if(!focused)StopVibration();return;}
 if(doorNativePending){
  doorElapsed+=dt;Field<uint32_t>(g,0x170)&=~0x10000000u;Field<uint32_t>(p,4)=(Field<uint32_t>(p,4)&~2u)|0x20u;
  if(doorElapsed>.2f&&p[0xfc]==doorRoutineBefore){
   float yaw=cameraYaw,pitch=cameraPitch,distance=cameraDistance;Vec safe=recovery;Enable(p,g);recovery=safe;cameraYaw=yaw;cameraPitch=pitch;cameraDistance=distance;doorCooldown=GetTickCount64()+700;
   Log("Native door action complete: Mario retained; door collision refreshed.");return;
  }
  if(doorElapsed>7){Log("Native door action timed out: handing control back to Leon.");ReturnToLeon();return;}
  Vec native=ToSM(Field<Vec>(p,0x94));sm64_set_mario_position(marioId,native.x,native.y,native.z);sm64_set_mario_velocity(marioId,0,0,0);sm64_set_mario_forward_velocity(marioId,0);sm64_set_mario_faceangle(marioId,Field<Vec>(p,0xa0).y);sm64_set_mario_action(marioId,0x0c400201);
  SM64MarioInputs idle{};idle.camLookZ=1;sm64_mario_tick(marioId,&idle,&state,&geometry);UpdateGround();PumpAudio();accumulator=0;return;
 }
 Field<uint32_t>(g,0x170)|=0x10000000;
 // TRANS hides Leon; MOVE must stay set because native enemy hit tests require it.
 // Leon's actual update remains stopped by GLOBAL's PL stop flag.
 Field<uint32_t>(p,4)=(Field<uint32_t>(p,4)&~0x2u)|0x20u;
 // The stopped native player cannot tick its old invulnerability timer down.
 p[0x32c]=0;p[0x32d]=GetTickCount64()<hurtUntil?1:0;
 accumulator+=dt;
 cameraYaw+=((float)Down(VK_RIGHT)-(float)Down(VK_LEFT))*dt*2.2f;cameraPitch+=((float)Down(VK_UP)-(float)Down(VK_DOWN))*dt*1.5f;
 float leftX=0,leftY=0,rightX=0,rightY=0;
 if(hasPad){leftX=-pad.Gamepad.sThumbLX/32767.f;leftY=pad.Gamepad.sThumbLY/32767.f;rightX=pad.Gamepad.sThumbRX/32767.f;rightY=pad.Gamepad.sThumbRY/32767.f;
  MarioCamera::Deadzone(leftX,leftY);MarioCamera::Deadzone(rightX,rightY);cameraYaw-=rightX*dt*2.5f;cameraPitch+=rightY*dt*1.8f;
 }
 cameraYaw-=mouseX*.004f;cameraPitch+=mouseY*.003f;mouseX=mouseY=0;
 cameraYaw=std::remainder(cameraYaw,6.2831853f);cameraPitch=std::clamp(cameraPitch,-.20f,1.0f);
 cameraDistance=std::clamp(cameraDistance+((float)Down(VK_OEM_MINUS)-(float)Down(VK_OEM_PLUS))*dt*1800,500.f,5000.f);
 auto camera=g+0x74;
 SM64MarioInputs inputs{};inputs.camLookX=sinf(cameraYaw);inputs.camLookZ=cosf(cameraYaw);
 float keyboardX=(float)Down('D')-(float)Down('A'),keyboardY=(float)Down('W')-(float)Down('S');
 float keyboardSpeed=Down(VK_SHIFT)?1.f:.65f;
 inputs.stickX=keyboardX!=0?keyboardX*keyboardSpeed:leftX;inputs.stickY=keyboardY!=0?keyboardY*keyboardSpeed:leftY;
 float mag=sqrtf(inputs.stickX*inputs.stickX+inputs.stickY*inputs.stickY);if(mag>1){inputs.stickX/=mag;inputs.stickY/=mag;}
 inputs.buttonA=Down(VK_SPACE)||(padButtons&XINPUT_GAMEPAD_A);
 bool attack=attackKey||(padButtons&(XINPUT_GAMEPAD_X|XINPUT_GAMEPAD_B));
 bool triggerCrouch=hasPad&&pad.Gamepad.bLeftTrigger>30;
 // LT is SM64's Z: crouch on the ground, ground pound in the air. RT is unused.
 inputs.buttonB=attack;inputs.buttonZ=Down(VK_CONTROL)||triggerCrouch;
 doorWalkIntent=mag>.35f&&!inputs.buttonA&&!inputs.buttonZ&&!(state.action&0x800);
 while(accumulator>=1./30){auto oldAction=state.action;Vec previous{state.position[0],state.position[1],state.position[2]};
  // Share RE4's real HP: switching characters or resetting does not heal combat damage.
  float healthRatio=std::clamp(Field<int16_t>(g,0x4fb4)/(float)std::max(1,(int)Field<int16_t>(g,0x4fb6)),0.f,1.f);
  sm64_set_mario_health(marioId,(int16_t)(0x100+0x780*healthRatio));
  // 22 units/frame ~= 4.95 m/s; retains >20 required by SM64's triple jump.
  if(GetTickCount64()>=hurtUntil&&fabsf(state.forwardVelocity)>22)sm64_set_mario_forward_velocity(marioId,std::clamp(state.forwardVelocity,-22.f,22.f));
  sm64_mario_tick(marioId,&inputs,&state,&geometry);
  if(GetTickCount64()>=hurtUntil&&fabsf(state.forwardVelocity)>22){state.forwardVelocity=std::clamp(state.forwardVelocity,-22.f,22.f);sm64_set_mario_forward_velocity(marioId,state.forwardVelocity);}
  TryDrop(inputs,previous);CombatTick();UpdateGround();accumulator-=1./30;++tickCount;
  if(state.action!=oldAction&&(state.action==0x008008a9||state.action==0x0080023c)&&hasPad&&setPadState){XINPUT_VIBRATION vibration{6000,9000};setPadState(padIndex,&vibration);vibrationUntil=GetTickCount64()+120;Log("Ground pound: light XInput vibration 120 ms.");}
 }
 Vec pos=ToRE({state.position[0],state.position[1],state.position[2]});
 if(!std::isfinite(pos.x)||!std::isfinite(pos.y)||!std::isfinite(pos.z)||state.position[1]<-3000){Log("Fall/invalid state: resetting to activation point.");Recover(p,g);return;}
 SyncProxy(p,pos);PumpAudio();
 lastPlayable=Snapshot(g,pos,state.faceAngle);
 static ULONGLONG nextLog=0;auto timestamp=GetTickCount64();if(timestamp>=nextLog){char line[320];snprintf(line,sizeof line,"tick=%llu pos=(%.1f %.1f %.1f) action=%08x triangles=%u fov=%.2f pad=%lu buttons=%04x LS=(%.2f %.2f) RS=(%.2f %.2f)",(unsigned long long)tickCount,pos.x,pos.y,pos.z,state.action,geometry.numTrianglesUsed,Field<float>(camera,0xc0),padIndex,padButtons,leftX,leftY,rightX,rightY);Log(line);nextLog=timestamp+2000;}
}
static void __cdecl HookPadRead(){
 originalPadRead();Frame(nullptr);
 auto global=globalPtr?*globalPtr:nullptr;
 if((active||consumeGameplayInput)&&Readable(global,0x174)&&global[0x20]==3&&!Cinematic(global)&&!(Field<uint32_t>(global,0x170)&0x82000000)){
  // Preserve native pause/map commands while keeping Mario active through their menus.
  constexpr uint64_t menuCommands=0x2000ull|0x200000ull;
  *gameKeyOn&=menuCommands;*gameKeyTrigger&=menuCommands;
  if(padStartEdge){*gameKeyOn|=0x2000;*gameKeyTrigger|=0x2000;Log("Start: native RE4 pause requested.");}
  if(padMapEdge){*gameKeyOn|=0x200000;*gameKeyTrigger|=0x200000;Log("Y: native RE4 map requested; Mario remains active.");}
 }
}
using EndSceneFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*);
using PresentFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,const RECT*,const RECT*,HWND,const RGNDATA*);
using CreateDeviceFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3D9*,UINT,D3DDEVTYPE,HWND,DWORD,D3DPRESENT_PARAMETERS*,IDirect3DDevice9**);
static EndSceneFn originalEnd;
static PresentFn originalPresent;
static CreateDeviceFn originalCreate;
static void Patch(void** slot,void* hook) {DWORD old;VirtualProtect(slot,sizeof(void*),PAGE_EXECUTE_READWRITE,&old);*slot=hook;VirtualProtect(slot,sizeof(void*),old,&old);}
using SetTargetFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,DWORD,IDirect3DSurface9*);
using SetDepthFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,IDirect3DSurface9*);
using SetViewportFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,const D3DVIEWPORT9*);
using ClearFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,DWORD,const D3DRECT*,DWORD,D3DCOLOR,float,DWORD);
using DipFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,D3DPRIMITIVETYPE,INT,UINT,UINT,UINT,UINT);
using DpFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,D3DPRIMITIVETYPE,UINT,UINT);
using DpUpFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,D3DPRIMITIVETYPE,UINT,const void*,UINT);
using DipUpFn=HRESULT(STDMETHODCALLTYPE*)(IDirect3DDevice9*,D3DPRIMITIVETYPE,UINT,UINT,UINT,const void*,D3DFORMAT,const void*,UINT);
static SetTargetFn originalTarget;
static SetDepthFn originalDepth;
static SetViewportFn originalViewport;
static UINT sceneWidth=0,sceneHeight=0;
static ClearFn originalClear;
static DipFn originalDip;
static DpFn originalDp;
static DpUpFn originalDpUp;
static DipUpFn originalDipUp;
static unsigned worldDraws=0;
static bool sceneMarioDrawn=false;
static bool RenderPlayable(){auto g=ownedGlobal;return active&&Readable(g,0x5020)&&g[0x20]==3&&!Cinematic(g)&&!(Field<uint32_t>(g,0x170)&0x82000000);}
static bool WorldPass(IDirect3DDevice9* dev){
 if(!RenderPlayable())return false;
 DWORD z=0,write=0,color=0;dev->GetRenderState(D3DRS_ZENABLE,&z);dev->GetRenderState(D3DRS_ZWRITEENABLE,&write);dev->GetRenderState(D3DRS_COLORWRITEENABLE,&color);
 if(!z||!write||(color&7)!=7)return false;
 D3DVIEWPORT9 vp{};if(FAILED(dev->GetViewport(&vp))||vp.Width<640||vp.Height<360)return false;
 // RE4's GX camera can stay 4:3 while the actual native target is widescreen.
 // Match the observed full-size viewport, not the GX matrix's aspect ratio.
 if(vp.Width!=sceneWidth||vp.Height!=sceneHeight)return false;
 IDirect3DSurface9* depth=nullptr;bool valid=SUCCEEDED(dev->GetDepthStencilSurface(&depth))&&depth;
 if(depth)depth->Release();return valid;
}
static void CountWorldDraw(IDirect3DDevice9* dev,UINT primitives){
 MarioGuard guard;
 if(!overlayScene&&RenderPlayable()){
  DWORD z=0,write=0,color=0;D3DVIEWPORT9 vp{};dev->GetViewport(&vp);dev->GetRenderState(D3DRS_ZENABLE,&z);dev->GetRenderState(D3DRS_ZWRITEENABLE,&write);dev->GetRenderState(D3DRS_COLORWRITEENABLE,&color);
  static std::vector<uint64_t> seen;uint64_t key=((uint64_t)vp.Width<<32)|((uint64_t)vp.Height<<16)|(z<<8)|(write<<7)|color;
  if(seen.size()<32&&std::find(seen.begin(),seen.end(),key)==seen.end()){
   seen.push_back(key);IDirect3DSurface9* depth=nullptr;dev->GetDepthStencilSurface(&depth);D3DSURFACE_DESC desc{};if(depth){depth->GetDesc(&desc);depth->Release();}
   char line[240];snprintf(line,sizeof line,"World pass diagnostic: viewport=%lux%lu z=%lu write=%lu color=%lx depth=%ux%u primitives=%u cameraAspect=%.3f",vp.Width,vp.Height,z,write,color,desc.Width,desc.Height,primitives,fabsf(Field<float>(ownedGlobal,0x74+0x64+20)/Field<float>(ownedGlobal,0x74+0x64)));Log(line);
  }
 }
 if(!overlayScene&&!sceneMarioDrawn&&primitives>2&&WorldPass(dev))++worldDraws;
}
static void FinishWorldPass(IDirect3DDevice9* dev){
 MarioGuard guard;
 if(overlayScene||sceneMarioDrawn||worldDraws<8||!RenderPlayable())return;
 IDirect3DSurface9* depth=nullptr;if(FAILED(dev->GetDepthStencilSurface(&depth))||!depth)return;
 D3DSURFACE_DESC description{};depth->GetDesc(&description);depth->Release();
 overlayScene=true;drawingNativeDepth=true;Draw(dev,ownedGlobal);drawingNativeDepth=false;overlayScene=false;sceneMarioDrawn=true;
 static ULONGLONG nextReport=0;auto now=GetTickCount64();if(now>=nextReport){char line[180];snprintf(line,sizeof line,"Native scene Mario: depth=%ux%u format=%u worldDraws=%u Z-test=on Z-write=on",description.Width,description.Height,description.Format,worldDraws);Log(line);nextReport=now+3000;}
}
static HRESULT STDMETHODCALLTYPE HookTarget(IDirect3DDevice9* dev,DWORD index,IDirect3DSurface9* target){
 if(!overlayScene&&index==0){IDirect3DSurface9* old=nullptr;dev->GetRenderTarget(0,&old);if(old!=target){FinishWorldPass(dev);worldDraws=0;}if(old)old->Release();}
 return originalTarget(dev,index,target);
}
static HRESULT STDMETHODCALLTYPE HookDepth(IDirect3DDevice9* dev,IDirect3DSurface9* depth){
 if(!overlayScene){IDirect3DSurface9* old=nullptr;dev->GetDepthStencilSurface(&old);if(old!=depth){FinishWorldPass(dev);worldDraws=0;}if(old)old->Release();}
 return originalDepth(dev,depth);
}
static HRESULT STDMETHODCALLTYPE HookViewport(IDirect3DDevice9* dev,const D3DVIEWPORT9* viewport){
 if(!overlayScene&&viewport){D3DVIEWPORT9 old{};dev->GetViewport(&old);if(old.X!=viewport->X||old.Y!=viewport->Y||old.Width!=viewport->Width||old.Height!=viewport->Height){FinishWorldPass(dev);worldDraws=0;}}
 return originalViewport(dev,viewport);
}
static HRESULT STDMETHODCALLTYPE HookClear(IDirect3DDevice9* dev,DWORD count,const D3DRECT* rect,DWORD flags,D3DCOLOR color,float z,DWORD stencil){
 if(!overlayScene&&(flags&(D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER))){if(!(flags&D3DCLEAR_TARGET))FinishWorldPass(dev);worldDraws=0;}
 return originalClear(dev,count,rect,flags,color,z,stencil);
}
static HRESULT STDMETHODCALLTYPE HookDip(IDirect3DDevice9* dev,D3DPRIMITIVETYPE type,INT base,UINT min,UINT vertices,UINT start,UINT primitives){auto result=originalDip(dev,type,base,min,vertices,start,primitives);if(SUCCEEDED(result))CountWorldDraw(dev,primitives);return result;}
static HRESULT STDMETHODCALLTYPE HookDp(IDirect3DDevice9* dev,D3DPRIMITIVETYPE type,UINT start,UINT primitives){auto result=originalDp(dev,type,start,primitives);if(SUCCEEDED(result))CountWorldDraw(dev,primitives);return result;}
static HRESULT STDMETHODCALLTYPE HookDpUp(IDirect3DDevice9* dev,D3DPRIMITIVETYPE type,UINT primitives,const void* data,UINT stride){auto result=originalDpUp(dev,type,primitives,data,stride);if(SUCCEEDED(result))CountWorldDraw(dev,primitives);return result;}
static HRESULT STDMETHODCALLTYPE HookDipUp(IDirect3DDevice9* dev,D3DPRIMITIVETYPE type,UINT min,UINT vertices,UINT primitives,const void* indices,D3DFORMAT format,const void* data,UINT stride){auto result=originalDipUp(dev,type,min,vertices,primitives,indices,format,data,stride);if(SUCCEEDED(result))CountWorldDraw(dev,primitives);return result;}
static HRESULT STDMETHODCALLTYPE HookEnd(IDirect3DDevice9* dev){if(!overlayScene&&!checked){checked=true;Prepare();}FinishWorldPass(dev);worldDraws=0;return originalEnd(dev);}
static HRESULT STDMETHODCALLTYPE HookPresent(IDirect3DDevice9* dev,const RECT* src,const RECT* dest,HWND window,const RGNDATA* dirty){
 MarioGuard guard;
 static ULONGLONG nextMissing=0;if(RenderPlayable()&&!sceneMarioDrawn&&GetTickCount64()>=nextMissing){Log("Native scene Mario: no suitable world pass found; temporary visible fallback retained for diagnosis.");nextMissing=GetTickCount64()+3000;}
 if(RenderPlayable()&&!sceneMarioDrawn){
  IDirect3DSurface9 *back=nullptr,*old=nullptr,*depth=nullptr;D3DVIEWPORT9 saved{};dev->GetRenderTarget(0,&old);dev->GetDepthStencilSurface(&depth);dev->GetViewport(&saved);overlayScene=true;
  if(SUCCEEDED(dev->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&back))){D3DSURFACE_DESC desc{};back->GetDesc(&desc);dev->SetDepthStencilSurface(nullptr);dev->SetRenderTarget(0,back);D3DVIEWPORT9 vp{0,0,desc.Width,desc.Height,0,1};dev->SetViewport(&vp);
   if(SUCCEEDED(dev->BeginScene())){Draw(dev,ownedGlobal);dev->EndScene();}back->Release();if(old)dev->SetRenderTarget(0,old);dev->SetDepthStencilSurface(depth);dev->SetViewport(&saved);
  }if(old)old->Release();if(depth)depth->Release();overlayScene=false;
 }
 worldDraws=0;sceneMarioDrawn=false;return originalPresent(dev,src,dest,window,dirty);
}

static HRESULT STDMETHODCALLTYPE HookCreate(IDirect3D9* obj,UINT adapter,D3DDEVTYPE type,HWND window,DWORD behavior,D3DPRESENT_PARAMETERS* params,IDirect3DDevice9** device){
 HRESULT hr=originalCreate(obj,adapter,type,window,behavior,params,device);if(SUCCEEDED(hr)&&device&&*device){gameWindow=window;
  IDirect3DSurface9* back=nullptr;if(SUCCEEDED((*device)->GetBackBuffer(0,0,D3DBACKBUFFER_TYPE_MONO,&back))){D3DSURFACE_DESC description{};back->GetDesc(&description);sceneWidth=description.Width;sceneHeight=description.Height;back->Release();}
  if(!originalWndProc){SetLastError(0);auto previous=(WNDPROC)SetWindowLongPtrW(window,GWLP_WNDPROC,(LONG_PTR)HookWndProc);if(previous)originalWndProc=previous;}
  auto table=*(void***)(*device);
  if(table[37]!=(void*)HookTarget){originalTarget=(SetTargetFn)table[37];Patch(&table[37],(void*)HookTarget);}
  if(table[39]!=(void*)HookDepth){originalDepth=(SetDepthFn)table[39];Patch(&table[39],(void*)HookDepth);}
  if(table[43]!=(void*)HookClear){originalClear=(ClearFn)table[43];Patch(&table[43],(void*)HookClear);}
  if(table[47]!=(void*)HookViewport){originalViewport=(SetViewportFn)table[47];Patch(&table[47],(void*)HookViewport);}
  if(table[81]!=(void*)HookDp){originalDp=(DpFn)table[81];Patch(&table[81],(void*)HookDp);}
  if(table[82]!=(void*)HookDip){originalDip=(DipFn)table[82];Patch(&table[82],(void*)HookDip);}
  if(table[83]!=(void*)HookDpUp){originalDpUp=(DpUpFn)table[83];Patch(&table[83],(void*)HookDpUp);}
  if(table[84]!=(void*)HookDipUp){originalDipUp=(DipUpFn)table[84];Patch(&table[84],(void*)HookDipUp);}
  if(table[42]!=(void*)HookEnd){originalEnd=(EndSceneFn)table[42];Patch(&table[42],(void*)HookEnd);}if(table[17]!=(void*)HookPresent){originalPresent=(PresentFn)table[17];Patch(&table[17],(void*)HookPresent);}}return hr;
}

// ASI startup uses a normal game call hook, not a proxy export.
using FactoryFn=IDirect3D9*(WINAPI*)(UINT);
static FactoryFn originalFactory=nullptr;
static volatile LONG asiInitState=0;
static IDirect3D9* WINAPI HookFactory(UINT sdk){
 auto obj=originalFactory?originalFactory(sdk):nullptr;
 if(obj){auto table=*(void***)obj;if(table[16]!=(void*)HookCreate){originalCreate=(CreateDeviceFn)table[16];Patch(&table[16],(void*)HookCreate);}}
 return obj;
}
static void StartupMessage(const char* message){
 wchar_t path[MAX_PATH];GetModuleFileNameW(selfModule,path,MAX_PATH);std::wstring dir=path;dir=dir.substr(0,dir.find_last_of(L"\\/"));
 auto file=_wfopen((dir+L"\\re4-mario-asi-loader.log").c_str(),L"a");if(file){fprintf(file,"%s\n",message);fclose(file);}
}
static void StartAsi(){
 if(InterlockedCompareExchange(&asiInitState,1,0)!=0)return;
 // Keep the module resident while its normal game hooks are installed.
 HMODULE pinned=nullptr;
 if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)(uintptr_t)&StartAsi,&pinned)){
  StartupMessage("Could not keep ASI resident; hooks not installed.");InterlockedExchange(&asiInitState,-1);return;
 }
 auto site=FindUnique("E8 ? ? ? ? A3 ? ? ? ? 85 C0 75 17");
 if(!site || site[0]!=0xe8){StartupMessage("Unsupported Direct3D creation signature; ASI disabled.");InterlockedExchange(&asiInitState,-1);return;}
 auto target=site+5+*(int32_t*)(site+1);
 if(!Readable(target,5)){StartupMessage("Invalid Direct3D creation target; ASI disabled.");InterlockedExchange(&asiInitState,-1);return;}
 originalFactory=(FactoryFn)target;
 DWORD old=0;
 if(!VirtualProtect(site,5,PAGE_EXECUTE_READWRITE,&old)){StartupMessage("Could not install game call hook; ASI disabled.");InterlockedExchange(&asiInitState,-1);return;}
 *(int32_t*)(site+1)=(uint8_t*)HookFactory-site-5;
 VirtualProtect(site,5,old,&old);FlushInstructionCache(GetCurrentProcess(),site,5);
 auto factoryPtr=*(IDirect3D9***)(site+6);
 if(Readable(factoryPtr,sizeof(void*)) && *factoryPtr && Readable(*factoryPtr,sizeof(void*))){
  auto table=*(void***)(*factoryPtr);
  if(Readable(table,17*sizeof(void*)) && table[16]!=(void*)HookCreate){originalCreate=(CreateDeviceFn)table[16];Patch(&table[16],(void*)HookCreate);}
  StartupMessage("ASI loaded after factory creation: next device creation will be hooked. Load early during startup.");
 }
 StartupMessage("ASI x86 initialized. Direct3D proxy export not required. Awaiting the game's device creation.");
 InterlockedExchange(&asiInitState,2);
}
static DWORD WINAPI AsiWorker(LPVOID){StartAsi();return 0;}
// Ultimate ASI Loader can call this outside DllMain. The guard prevents duplicates.
extern "C" void InitializeASI(){StartAsi();}
BOOL WINAPI DllMain(HINSTANCE module,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH){
  selfModule=module;DisableThreadLibraryCalls(module);
  // Never wait here. The worker starts after loader notifications complete.
  HANDLE worker=CreateThread(nullptr,0,AsiWorker,nullptr,0,nullptr);
  if(worker)CloseHandle(worker);
 }
 return TRUE;
}
