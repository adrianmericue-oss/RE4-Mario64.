# Compilar el código de integración x86

El archivo re4_mario_asi.cpp es la fuente completa correspondiente al ASI 0.7.1, incluidos los hooks de arranque. No requiere el antiguo proxy d3d9.

Necesitas Python, un toolchain LLVM-MinGW para Windows con destino i686 y libsm64. Consulta el repositorio de libsm64 para sus fuentes y licencia. Compila libsm64 para i686 con VERSION_US, GBI_FLOATS y NO_SEGMENTED_MEMORY; conserva sm64.dll y su import library i686_sm64.a. El script build_libsm64.py reproduce las opciones usadas y espera libsm64-master/ y toolchain/llvm-mingw-20260922-ucrt-x86_64/bin/ junto al script. Los fuentes externos y el toolchain no se incluyen.

Con los encabezados de libsm64 en libsm64-master/src y la import library en sm64-build:

```powershell
i686-w64-mingw32-clang++.exe -m32 -std=c++17 -O2 -shared -static -I libsm64-master/src -I . re4_mario_asi.cpp re4_mario_asi.def sm64-build/i686_sm64.a -o re4-mario.asi -luser32 -ld3d9 -lwinmm
```

La compilación anterior genera un módulo sin la firma local usada para la prueba. Los hashes distribuidos corresponden a los binarios firmados. La firma no se necesita para compilar el código y su clave privada no forma parte de este paquete.
