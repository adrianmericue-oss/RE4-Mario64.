#pragma once
#include <cmath>
#include <algorithm>
#include <vector>
struct Vec { float x,y,z; };
namespace MarioCamera {
struct Triangle {Vec a,b,c;};
inline Vec Add(Vec a,Vec b){return {a.x+b.x,a.y+b.y,a.z+b.z};}
inline Vec Sub(Vec a,Vec b){return {a.x-b.x,a.y-b.y,a.z-b.z};}
inline Vec Mul(Vec a,float f){return {a.x*f,a.y*f,a.z*f};}
inline float Dot(Vec a,Vec b){return a.x*b.x+a.y*b.y+a.z*b.z;}
inline Vec Cross(Vec a,Vec b){return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
inline float Length(Vec v){return std::sqrt(Dot(v,v));}
inline Vec Unit(Vec v){float n=Length(v);return n>0.001f?Mul(v,1.f/n):Vec{0,0,1};}
inline Vec Lerp(Vec a,Vec b,float f){return Add(a,Mul(Sub(b,a),f));}
// Two-sided segment intersection: SAT triangle winding must not hide back faces.
inline float RayTriangle(Vec from,Vec to,const Triangle& t){
 Vec d=Sub(to,from),e1=Sub(t.b,t.a),e2=Sub(t.c,t.a),h=Cross(d,e2);
 float det=Dot(e1,h);if(std::fabs(det)<0.001f)return 1;
 float inv=1/det;Vec s=Sub(from,t.a);float u=Dot(s,h)*inv;
 if(u<0||u>1)return 1;Vec q=Cross(s,e1);float v=Dot(d,q)*inv;
 if(v<0||u+v>1)return 1;float hit=Dot(e2,q)*inv;
 return hit>0.00001f&&hit<1?hit:1;
}
inline float RayWorld(Vec from,Vec to,const std::vector<Triangle>& triangles){
 float nearest=1;
 for(const auto& t:triangles){
  if(std::max({t.a.x,t.b.x,t.c.x})<std::min(from.x,to.x)||std::min({t.a.x,t.b.x,t.c.x})>std::max(from.x,to.x)||
     std::max({t.a.y,t.b.y,t.c.y})<std::min(from.y,to.y)||std::min({t.a.y,t.b.y,t.c.y})>std::max(from.y,to.y)||
     std::max({t.a.z,t.b.z,t.c.z})<std::min(from.z,to.z)||std::min({t.a.z,t.b.z,t.c.z})>std::max(from.z,to.z))continue;
  nearest=std::min(nearest,RayTriangle(from,to,t));
 }
 return nearest;
}
inline Vec Collide(Vec target,Vec desired,const std::vector<Triangle>& triangles,float radius=120){
 Vec delta=Sub(desired,target);float distance=Length(delta);if(distance<0.001f)return desired;
 Vec right=Unit(Cross({0,1,0},delta)),up=Unit(Cross(delta,right));
 float hit=1;
 for(Vec offset:{Vec{0,0,0},Mul(right,radius),Mul(right,-radius),Mul(up,radius),Mul(up,-radius)})
  hit=std::min(hit,RayWorld(Add(target,offset),Add(desired,offset),triangles));
 if(hit>=1)return desired;
 return Add(target,Mul(delta,std::max(0.f,hit-radius/distance)));
}
inline void Deadzone(float& x,float& y,float deadzone=.2f){
 float magnitude=std::sqrt(x*x+y*y);if(magnitude<=deadzone){x=y=0;return;}
 float adjusted=std::clamp((magnitude-deadzone)/(1-deadzone),0.f,1.f)/magnitude;x*=adjusted;y*=adjusted;
}
}
