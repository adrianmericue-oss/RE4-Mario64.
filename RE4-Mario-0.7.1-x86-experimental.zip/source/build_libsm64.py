from pathlib import Path
import subprocess, concurrent.futures, sys
root = Path(__file__).resolve().parent
src = root / 'libsm64-master'
tool = root / 'toolchain/llvm-mingw-20260922-ucrt-x86_64/bin'
build = root / 'sm64-build'
build.mkdir(exist_ok=True)
dirs = ['src','src/decomp','src/decomp/engine','src/decomp/include/PR','src/decomp/game','src/decomp/pc','src/decomp/pc/audio','src/decomp/mario','src/decomp/tools','src/decomp/audio']
files = [p for d in dirs for p in (src/d).glob('*.c')]
arch = sys.argv[1] if len(sys.argv)>1 else 'i686'
cc = tool / f'{arch}-w64-mingw32-clang.exe'
flags = ['-O2','-fno-strict-aliasing','-Wno-unused-function','-Wno-incompatible-pointer-types','-Wno-implicit-function-declaration','-DSM64_LIB_EXPORT','-DGBI_FLOATS','-DVERSION_US','-DNO_SEGMENTED_MEMORY','-I',str(src/'src/decomp/include')]
def compile(p):
    obj = build / (arch+'_'+str(p.relative_to(src)).replace('\\','_').replace('/','_')+'.o')
    r = subprocess.run([str(cc),*flags,'-c',str(p),'-o',str(obj)],capture_output=True,text=True)
    if r.returncode: raise RuntimeError(str(p)+'\n'+r.stderr)
    return obj
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    objs = list(pool.map(compile,files))
out = build / ('sm64.dll' if arch=='i686' else 'sm64-test64.dll')
subprocess.run([str(cc),'-shared','-o',str(out),*[str(p) for p in objs],'-lm','-Wl,--out-implib,'+str(build/(arch+'_sm64.a'))],check=True)
print(f'Compiled {len(files)} sources: {out}')
