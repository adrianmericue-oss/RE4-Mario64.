# Mario en Resident Evil 4 — experimental 0.7.1

Para Resident Evil 4 clásico de Steam / Ultimate HD Edition, ejecutable bio4.exe de 32 bits en Bin32. No es un mod para el remake de 2023 ni para REFramework. Se ha probado en un equipo y ejecutable concretos; otras versiones, otros mods y todas las puertas no están comprobados.

## Instalación manual

1. Cierra RE4 y respalda los mods que tengas en Bin32.
2. Instala Ultimate ASI Loader de 32 bits desde su repositorio oficial: https://github.com/ThirteenAG/Ultimate-ASI-Loader . Utiliza su variante dinput8.dll en Bin32 junto a bio4.exe. El cargador no se incluye en este paquete. Si ya tienes dinput8.dll de otro mod, comprueba cómo combinar ambos antes de sustituirlo.
3. Copia re4-mario.asi y sm64.dll de la carpeta Bin32 del ZIP a la carpeta Bin32 del juego.
4. Proporciona tu propia ROM de Super Mario 64 USA en formato z64 big-endian (8 MiB) y llámala mario64.z64 en esa misma carpeta. No se distribuye ROM ni se facilitan enlaces para descargarla.
5. Arranca RE4 desde Steam, carga una partida y pulsa RB para activar Mario. F6 permite activarlo con teclado.

Para desinstalar, cierra RE4 y retira únicamente re4-mario.asi y sm64.dll de este paquete. No retires un cargador que necesiten tus otros mods. El registro re4-mario.log se genera en Bin32.

Los módulos llevan una firma local de prueba; no es una firma de Microsoft ni garantiza aceptación por Windows. Este paquete no incluye certificados, claves privadas ni comandos para cambiar la seguridad del sistema. Si Windows impide la carga, la instalación no está verificada en esa configuración.

## Controles

| Acción | Mando | Teclado |
|---|---|---|
| Alternar Mario / Leon | RB | F6 activa; F7/F8 vuelve a Leon |
| Cuchillo con Leon | LB, control nativo | Control nativo de RE4 |
| Mover Mario | Stick izquierdo | WASD; Shift para correr |
| Saltar | A | Espacio |
| Golpear | X o B | F |
| Agacharse en el suelo | LT | Ctrl |
| Salto bomba en el aire | LT después de saltar | Ctrl después de saltar |
| Cámara | Stick derecho | Ratón o flechas |
| Mapa | Y | M, control nativo |
| Pausa | Start/Menu | Esc |
| Recuperar posición | Back/View | R |

RT no tiene acción asignada a Mario. LB no cambia de personaje. Para abrir puertas, camina hacia ellas mirando de frente. Se usan las acciones y cerraduras de RE4.

## Estado y limitaciones

Combate, movimiento, sonido original extraído de la ROM local, cámara y dibujo se integran con RE4. Se conservan el render y los ajustes de 0.7. El ajuste 0.7.1 libera LB para Leon. Compilación x86 y arranque comprobados. La nueva interacción con puertas y LB/cuchillo requiere confirmación en partida. No se promete compatibilidad universal ni ausencia de errores; consulta PRUEBAS.md, que contiene también el historial de pruebas.

## Código, créditos y permisos

El código de integración incluido en source/ se distribuye bajo GPLv3, junto con su licencia y las instrucciones de compilación. Referencias de estructuras y hooks: re4_tweaks, https://github.com/nipkownix/re4_tweaks . Biblioteca libsm64: https://github.com/libsm64/libsm64 . Se incluye su aviso CC0 en LICENSE-libsm64.md. El código de SM64 procede de su proyecto de decompilación; las licencias de los colaboradores no otorgan derechos sobre propiedad de terceros.

No se incluyen archivos del juego RE4, ROM, texturas extraídas, grabaciones de audio, cargadores de terceros ni herramientas de seguridad. El uso local y la publicación en Nexus son cuestiones distintas: verifica los permisos de los componentes y las normas de Nexus antes de publicar. No se ha subido este paquete a ningún servicio.
