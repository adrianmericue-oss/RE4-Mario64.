# Ajuste 0.7.1 — LB para cuchillo de Leon

Eliminada la activación mediante LB del input del mod. Con Leon activo no se filtra su input nativo; RB conserva la alternancia de personajes y F6 la activación por teclado. Compilación x86 y comprobaciones estáticas correctas. Pendiente confirmación física de LB/cuchillo en partida.

# Pruebas 0.7 — LT y puertas

- Compilación PE32 x86 de ASI y libsm64 comprobada.
- Física real libsm64 con la ROM local: agacharse=1, triple salto=1, salto bomba=1, aterrizaje del salto bomba=1; 752 triángulos. Ver `prueba-LT-v07.txt`.
- ActionButton::set y ActionButton::checkButton: patrones y saltos indirectos únicos comprobados en bio4.exe, junto con los hooks de cámara, input y combate. Ver `verificacion-estatica.json`.
- RT no participa en el input de Mario. LT alimenta el botón Z nativo en suelo y aire.

RE4 ha arrancado con la versión 0.7; el registro confirma los nuevos hooks de puertas activos y mando XInput conectado en el puerto 0. Se conservó la versión anterior en backup-v06 y los hashes instalados coinciden con arquitectura.json.

Pendiente de prueba en partida: A seguido de LT; RT sin agacharse; puertas físicas de frente y de espaldas; puerta de cambio de sala; puerta cerrada con llave. El registro indicará la aceptación de la puerta y el final de su acción nativa. Compilación y patrones correctos no demuestran por sí solos estas interacciones.

# Versión 0.6: oclusión de Mario

Compilación x86 completada. Módulos firmados con el mismo certificado local y arquitectura/exports/patrones comprobados. La versión 0.5 anterior se conserva en backup-v05.

Corrección: prueba Z activada, cuerpo escribe Z, proyección GX convertida al intervalo D3D, dibujo antes de cambiar el destino/profundidad del pase nativo, sin superposición en Present cuando se encuentra el pase nativo; conserva dibujo visible como fallback de diagnóstico.

El diagnóstico real mostró viewport y profundidad de 1280x800, mientras la matriz GX seguía en 4:3. Se corrigió el selector para usar las dimensiones reales. Un cierre con excepción c0000005 en RenderPlayable (offset 0x27a8) llevó a sincronizar la vida del personaje con el dibujo.

Prueba de la compilación final en RE4: se detectó profundidad nativa de 1280x800 (formato D24S8), se dibujó Mario en el pase principal y se comprobó por captura que vuelve a verse completo. Varias alternancias Mario/Leon se registraron sin otro cierre durante la sesión. Falta confirmar visualmente la oclusión exacta por enemigos en la cabaña. Registro: registro-prueba-v06.txt. Los resultados anteriores corresponden a 0.5 o versiones previas.

---

# Versión 0.5: cinemáticas, hitbox, audio y bajadas

Compilación x86 de ASI y biblioteca. La hitbox de Leon ya no se sustituye por una cápsula pequeña; el ataque aceptado por RE4 no se descarta por un segundo filtro geométrico.

Pruebas ejecutadas con libsm64 real y la ROM local:

- Audio original: estéreo PCM a 32000 Hz, 14186 muestras no nulas, pico 22417.
- Controles con límite de velocidad: triple salto, ground pound y aterrizaje correctos.
- Bajadas: permite borde bajo, rechaza pared sólida y ausencia de suelo; la caída llega al suelo inferior sin botón de acción.
- Clasificación de progreso: estado idéntico y bandera de entrada no cuentan; bandera de puerta abierta sí cuenta.

Las pruebas de bajada usan un escenario sintético y física SM64; no prueban todas las acciones guionizadas de RE4. La restitución exacta se comprobó en dos cinemáticas reales; falta validar una que avance la historia y use el punto final de Leon. Queda pendiente confirmar la audición por el usuario; un impacto enemigo real ya redujo la vida con la hitbox completa.

Comprobación en RE4 con el usuario jugando, versión 0.5:

- Carga correcta: XInput conectado, hooks de cámara/input/combate y audio WinMM open=0.
- Dos cinemáticas: storyProgress=0, posición guardada restaurada. En la segunda, Leon terminaba a unos 4,7 m del punto guardado; se eligió el punto exacto anterior de Mario.
- Ataque nativo recibido: HP 1200 -> 934, con retroceso.
- Puñetazos a ganado id 0x12: HP 500 -> 116 -> 0.
- RB registra entrega de posición actual a Leon; falta confirmación visual de que la colisión nativa posterior no la corrige.
- Pendiente: cinemática con avance de historia, audición del usuario y una bajada asistida en un borde real.

Registro conservado en registro-prueba-v05.txt.

---

# Versión 0.4: combate y apoyo en suelo

Pruebas automatizadas con la ROM del usuario y libsm64 x86:

```
idleHit=0 frontPunch=1 rearPunch=0 health=880 -> 780 knockbackVelocity=-4.5
scale=7.5 height_mm=1098.6 groundedFeetGap_mm=0.0000 floorNormalY=1.0
```

Se comprobaron las firmas únicas de EmAtkSetDamagePL, resta de HP, cDmgInfo::Set y cEmMgr en bio4.exe. El thunk del ataque enemigo es único. La firma genérica del SDK coincidía con otros gestores; se restringió al contexto del gestor de enemigos con stride inicial 0xE08. Se conservaron texturas y biblioteca SM64.

Prueba en el juego, ejecutada con el usuario manejando el mando:

- Primera compilación: registro de impactos en ganados id 0x12 y pérdida de HP. La reacción nativa aplicaba una segunda resta; se corrigió para delegar todo el daño al registro de patada nativa.
- Integración final de daño: enemigo id 0x23 HP 10 -> 0; ganado id 0x12 HP 500 -> 116 -> 0, con dos golpes registrados y sin resta adicional del mod. Estas pruebas preceden al último ajuste del hurtbox de Mario.
- Cámara/input y render continúan activos en la partida. El motor dibuja 24 triángulos de sombra; suelo válido y corrección de apoyo registrados con escala 7,50.
- En la primera revisión visual Mario está completo y sobre el terreno; las texturas no han cambiado. Pendiente de confirmar visualmente el contraste de la sombra final.
- Pendiente: ataque enemigo a Mario, separación corporal junto a ganados, muerte nativa del jugador y revisión visual sobre diferentes pendientes. No se han validado todos los jefes ni rutinas especiales de daño.

La compilación final mantiene MOVE (0x20), exigido por tests de impactos nativos, mientras oculta TRANS (0x2) y detiene la actualización de Leon con PL stop. El temporizador nativo de invulnerabilidad se sincroniza con el intervalo del mod para evitar que se quede congelado.

---

# Pruebas de la versión 0.2

Actualización 0.3: eje horizontal del mando corregido y mapeo cambiado a A salto, X/B ataque, Y mapa sin desactivar Mario, RB alternancia y LT/RT agacharse. La prueba `prueba-direccion-mando.txt` usa libsm64 real y mide el desplazamiento respecto a la derecha de la cámara: ocho casos (izquierda/derecha en cuatro orientaciones), cero fallos. La compilación e instalación x86 se han verificado; la cámara/render se conservan. El nuevo Y/RB y los gatillos requieren confirmación física dentro del juego. Los registros y pruebas de cámara detallados debajo pertenecen a 0.2.

Compilación e instalación realizadas el 4 de octubre de 2026. Los hashes de los dos módulos instalados coinciden con `arquitectura.json`. La versión anterior está respaldada en `../backup-v01`.

Pruebas automáticas:

- Cámara: colisión de pared por ambas caras, margen de 12 cm, borde que toca el volumen de la cámara aunque no el rayo central, comprobación posterior a lerp, ausencia de obstáculo, zona muerta radial de 0.2 y altura inicial de 1500 mm. Resultado: PASS.
- libsm64 recompilado: Mario genera 752 triángulos, se desplaza 583.2 unidades y salta 324.7 unidades sobre el suelo de prueba. Resultado: PASS.
- Controles nativos de libsm64 sobre suelo de prueba: tripleJump=1, groundPound=1, poundLanding=1. Resultado: PASS. El wall kick se conserva en la física original, pero no se ha completado una prueba específica de salto en pared.
- La función `Draw` completa, incluida la creación de textura y sus materiales, es idéntica a la versión anterior. SHA-256 del bloque de código: `bbde6db772e22b7c21a66d1317cacb1dfc37b691b53e0415382bbc381b58882a`.

Prueba en RE4 instalado:

- ASI cargado y juego arrancado con los hooks `CameraControl::Move` y `PadRead` instalados.
- Mando conectado en XInput puerto 0, backend xinput1_3, API de vibración disponible.
- Partida de la sala 0103 cargada, 6890 triángulos de colisión extraídos y Mario activado con F6.
- Registro con desplazamiento mediante stick izquierdo, órbita mediante stick derecho y distancia solicitada modificada mediante gatillos; Mario sigue generando 752 triángulos y FOV=60.
- Colisiones de cámara registradas, con contracción de su distancia frente al obstáculo.
- Desactivación a Leon y nueva activación registradas.
- Start envió la pausa nativa y se observó el menú Opciones de RE4.

Pendiente de confirmación visual del usuario: comportamiento preciso junto a la cabaña, vibración física y pruebas completas de LB, Y y Back. Los registros no demuestran por sí solos que toda posible posición de cámara esté libre de intersecciones.

La prueba vigente está en `registro-prueba-actual.txt`; no confundirla con registros de versiones anteriores del prototipo.

Último ajuste: hurtbox raíz independiente de los huesos congelados de Leon, con restauración íntegra al volver a Leon. Se sincronizan las coordenadas globales de los huesos para los rayos nativos, sin cambiar transformaciones locales. La prueba de recibir daño queda pendiente de una partida con enemigo atacando.


